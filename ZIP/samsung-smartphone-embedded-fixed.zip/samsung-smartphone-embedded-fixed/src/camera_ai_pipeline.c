#include "camera_ai_pipeline.h"
CameraPipelineDecision galaxy_camera_pipeline_decide(CameraInput input){
    CameraPipelineDecision d={1,0,0,60};
    if(input.mode==CAMERA_MODE_NIGHT){ d.multi_frame_count=input.motion_score>70?4:8; d.npu_denoise_enabled=input.npu_available&&!input.thermal_limit; d.super_resolution_enabled=input.npu_available&&input.light_lux<50&&!input.thermal_limit; d.frame_rate_limit=30; }
    if(input.mode==CAMERA_MODE_PORTRAIT){ d.multi_frame_count=3; d.npu_denoise_enabled=input.npu_available; d.super_resolution_enabled=0; d.frame_rate_limit=60; }
    if(input.mode==CAMERA_MODE_8K_VIDEO){ d.multi_frame_count=1; d.npu_denoise_enabled=input.npu_available&&!input.thermal_limit; d.super_resolution_enabled=0; d.frame_rate_limit=input.thermal_limit?24:30; }
    if(input.mode==CAMERA_MODE_200MP_CAPTURE){ d.multi_frame_count=input.thermal_limit?1:3; d.npu_denoise_enabled=input.npu_available&&!input.thermal_limit; d.super_resolution_enabled=input.npu_available&&!input.thermal_limit; d.frame_rate_limit=15; }
    return d;
}
