#include "thermal_manager.h"
ThermalDecision galaxy_thermal_evaluate(float skin,float soc){
    ThermalDecision d;
    if(skin>=45.0f || soc>=88.0f){ d.state=THERMAL_CRITICAL; d.throttle_percent=70; d.camera_recording_limited=1; d.ai_boost_allowed=0; }
    else if(skin>=42.0f || soc>=82.0f){ d.state=THERMAL_HOT; d.throttle_percent=45; d.camera_recording_limited=1; d.ai_boost_allowed=0; }
    else if(skin>=38.5f || soc>=74.0f){ d.state=THERMAL_WARM; d.throttle_percent=20; d.camera_recording_limited=0; d.ai_boost_allowed=1; }
    else { d.state=THERMAL_NORMAL; d.throttle_percent=0; d.camera_recording_limited=0; d.ai_boost_allowed=1; }
    return d;
}
