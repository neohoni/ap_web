#include "battery_policy.h"
BatteryDecision galaxy_battery_decide(int battery,int charger,float skin){
    BatteryDecision d;
    if(battery<=5 || skin>=45.0f){ d.mode=BATTERY_MODE_CRITICAL; d.max_display_hz=60; d.background_ai_allowed=0; d.camera_high_res_allowed=0; }
    else if(battery<=20 || skin>=42.0f){ d.mode=BATTERY_MODE_SAVE; d.max_display_hz=60; d.background_ai_allowed=0; d.camera_high_res_allowed=1; }
    else if(charger && battery>=40 && skin<39.0f){ d.mode=BATTERY_MODE_PERFORMANCE; d.max_display_hz=120; d.background_ai_allowed=1; d.camera_high_res_allowed=1; }
    else { d.mode=BATTERY_MODE_NORMAL; d.max_display_hz=120; d.background_ai_allowed=1; d.camera_high_res_allowed=1; }
    return d;
}
