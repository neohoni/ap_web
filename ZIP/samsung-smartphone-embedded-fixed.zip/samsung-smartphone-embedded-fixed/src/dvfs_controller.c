#include "dvfs_controller.h"
static int clamp_int(int v,int lo,int hi){ if(v<lo)return lo; if(v>hi)return hi; return v; }
static PerformanceLevel load_to_level(int load){ load=clamp_int(load,0,100); if(load>=85)return PERF_BOOST; if(load>=65)return PERF_HIGH; if(load>=30)return PERF_BALANCED; return PERF_LOW; }
static int cpu_freq(PerformanceLevel l){ switch(l){case PERF_BOOST:return 3300;case PERF_HIGH:return 2800;case PERF_BALANCED:return 1900;default:return 900;} }
static int gpu_freq(PerformanceLevel l){ switch(l){case PERF_BOOST:return 1100;case PERF_HIGH:return 850;case PERF_BALANCED:return 500;default:return 250;} }
static int npu_freq(PerformanceLevel l){ switch(l){case PERF_BOOST:return 1400;case PERF_HIGH:return 1050;case PERF_BALANCED:return 650;default:return 250;} }
DvfsDecision galaxy_dvfs_decide(GalaxySystemInput input){
    PerformanceLevel cpu=load_to_level(input.cpu_load), gpu=load_to_level(input.gpu_load), npu=load_to_level(input.npu_load);
    if(input.workload==WORKLOAD_ON_DEVICE_AI && input.npu_load>=75 && input.soc_temp_c<78.0f && input.battery_percent>20) npu=PERF_BOOST;
    if(input.workload==WORKLOAD_CAMERA_CAPTURE && input.npu_load>=60 && input.soc_temp_c<75.0f){ npu=PERF_HIGH; if(cpu<PERF_BALANCED) cpu=PERF_BALANCED; }
    if(input.soc_temp_c>=88.0f || input.skin_temp_c>=45.0f || input.battery_percent<=7){ cpu=PERF_LOW; gpu=PERF_LOW; npu=PERF_LOW; }
    else if(input.soc_temp_c>=82.0f || input.skin_temp_c>=42.0f){ if(cpu>PERF_BALANCED)cpu=PERF_BALANCED; if(gpu>PERF_BALANCED)gpu=PERF_BALANCED; if(npu>PERF_BALANCED)npu=PERF_BALANCED; }
    DvfsDecision d={cpu,gpu,npu,cpu_freq(cpu),gpu_freq(gpu),npu_freq(npu)}; return d;
}
