#ifndef DVFS_CONTROLLER_H
#define DVFS_CONTROLLER_H
#include "galaxy_embedded_types.h"
typedef struct {
    PerformanceLevel cpu_level;
    PerformanceLevel gpu_level;
    PerformanceLevel npu_level;
    int cpu_freq_mhz;
    int gpu_freq_mhz;
    int npu_freq_mhz;
} DvfsDecision;
DvfsDecision galaxy_dvfs_decide(GalaxySystemInput input);
#endif
