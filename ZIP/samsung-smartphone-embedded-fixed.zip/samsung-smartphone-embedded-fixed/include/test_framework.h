#ifndef TEST_FRAMEWORK_H
#define TEST_FRAMEWORK_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define TEST_ASSERT_TRUE(expr) do { if (!(expr)) { printf("[FAIL] %s:%d: %s\n", __FILE__, __LINE__, #expr); exit(1); } } while (0)
#define TEST_ASSERT_EQUAL_INT(expected, actual) do { int e=(int)(expected); int a=(int)(actual); if(e!=a){ printf("[FAIL] %s:%d: expected %d, got %d\n", __FILE__, __LINE__, e, a); exit(1); } } while(0)
#define TEST_ASSERT_NEAR_FLOAT(expected, actual, tolerance) do { float e=(float)(expected); float a=(float)(actual); float t=(float)(tolerance); if(fabsf(e-a)>t){ printf("[FAIL] %s:%d: expected %.4f, got %.4f\n", __FILE__, __LINE__, e, a); exit(1); } } while(0)
#define RUN_TEST(fn) do { printf("[RUN ] %s\n", #fn); fn(); printf("[PASS] %s\n", #fn); } while (0)
#endif
