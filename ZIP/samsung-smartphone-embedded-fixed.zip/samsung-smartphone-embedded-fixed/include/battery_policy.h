#ifndef BATTERY_POLICY_H
#define BATTERY_POLICY_H
typedef enum { BATTERY_MODE_CRITICAL=0, BATTERY_MODE_SAVE, BATTERY_MODE_NORMAL, BATTERY_MODE_PERFORMANCE } BatteryMode;
typedef struct { BatteryMode mode; int max_display_hz; int background_ai_allowed; int camera_high_res_allowed; } BatteryDecision;
BatteryDecision galaxy_battery_decide(int battery_percent, int charger_connected, float skin_temp_c);
#endif
