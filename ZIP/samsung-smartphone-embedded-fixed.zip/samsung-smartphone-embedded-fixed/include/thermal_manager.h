#ifndef THERMAL_MANAGER_H
#define THERMAL_MANAGER_H
#include "galaxy_embedded_types.h"
typedef struct { ThermalState state; int throttle_percent; int camera_recording_limited; int ai_boost_allowed; } ThermalDecision;
ThermalDecision galaxy_thermal_evaluate(float skin_temp_c, float soc_temp_c);
#endif
