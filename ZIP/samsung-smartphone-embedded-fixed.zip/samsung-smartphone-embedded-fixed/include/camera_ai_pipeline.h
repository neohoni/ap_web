#ifndef CAMERA_AI_PIPELINE_H
#define CAMERA_AI_PIPELINE_H
typedef enum { CAMERA_MODE_PREVIEW=0, CAMERA_MODE_NIGHT, CAMERA_MODE_PORTRAIT, CAMERA_MODE_8K_VIDEO, CAMERA_MODE_200MP_CAPTURE } CameraMode;
typedef struct { CameraMode mode; int light_lux; int motion_score; int npu_available; int thermal_limit; } CameraInput;
typedef struct { int multi_frame_count; int npu_denoise_enabled; int super_resolution_enabled; int frame_rate_limit; } CameraPipelineDecision;
CameraPipelineDecision galaxy_camera_pipeline_decide(CameraInput input);
#endif
