#ifndef GALAXY_EMBEDDED_TYPES_H
#define GALAXY_EMBEDDED_TYPES_H
typedef enum { SOC_EXYNOS = 0, SOC_SNAPDRAGON = 1 } SocVendor;
typedef enum { WORKLOAD_IDLE = 0, WORKLOAD_UI, WORKLOAD_CAMERA_PREVIEW, WORKLOAD_CAMERA_CAPTURE, WORKLOAD_ON_DEVICE_AI, WORKLOAD_GAMING, WORKLOAD_VIDEO_ENCODING } WorkloadType;
typedef enum { PERF_LOW = 0, PERF_BALANCED, PERF_HIGH, PERF_BOOST } PerformanceLevel;
typedef enum { THERMAL_NORMAL = 0, THERMAL_WARM, THERMAL_HOT, THERMAL_CRITICAL } ThermalState;
typedef struct {
    SocVendor soc;
    WorkloadType workload;
    int cpu_load;
    int gpu_load;
    int npu_load;
    float skin_temp_c;
    float soc_temp_c;
    int battery_percent;
    int charger_connected;
} GalaxySystemInput;
#endif
