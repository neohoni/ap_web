# Samsung Smartphone Embedded Architecture Model

공개 가능한 Galaxy급 스마트폰 임베디드 제어 모델입니다.

## 구조

Application / Camera / AI Workload
→ DVFS Controller
→ Thermal Manager
→ Battery Policy
→ Camera AI Pipeline
→ HAL Mock

## 확장

- Exynos / Snapdragon profile
- PMU rail power budget
- camera sensor / ISP model
- on-device LLM workload policy
