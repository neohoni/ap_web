#include "camera_ai_pipeline.h"
#include "test_framework.h"
void test_camera_night_pipeline(void){
    CameraInput input={CAMERA_MODE_NIGHT,20,20,1,0}; CameraPipelineDecision d=galaxy_camera_pipeline_decide(input);
    TEST_ASSERT_EQUAL_INT(8,d.multi_frame_count); TEST_ASSERT_TRUE(d.npu_denoise_enabled); TEST_ASSERT_TRUE(d.super_resolution_enabled); TEST_ASSERT_EQUAL_INT(30,d.frame_rate_limit);
}
void test_camera_8k_thermal_limit(void){
    CameraInput input={CAMERA_MODE_8K_VIDEO,500,10,1,1}; CameraPipelineDecision d=galaxy_camera_pipeline_decide(input);
    TEST_ASSERT_EQUAL_INT(1,d.multi_frame_count); TEST_ASSERT_TRUE(!d.npu_denoise_enabled); TEST_ASSERT_EQUAL_INT(24,d.frame_rate_limit);
}
