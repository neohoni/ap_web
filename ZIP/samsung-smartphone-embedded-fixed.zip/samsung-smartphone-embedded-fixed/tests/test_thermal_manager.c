#include "thermal_manager.h"
#include "test_framework.h"
void test_thermal_states(void){
    ThermalDecision normal=galaxy_thermal_evaluate(35.0f,65.0f);
    ThermalDecision hot=galaxy_thermal_evaluate(42.5f,83.0f);
    ThermalDecision critical=galaxy_thermal_evaluate(45.5f,89.0f);
    TEST_ASSERT_EQUAL_INT(THERMAL_NORMAL,normal.state); TEST_ASSERT_EQUAL_INT(THERMAL_HOT,hot.state); TEST_ASSERT_EQUAL_INT(THERMAL_CRITICAL,critical.state);
    TEST_ASSERT_TRUE(critical.camera_recording_limited); TEST_ASSERT_TRUE(!critical.ai_boost_allowed);
}
