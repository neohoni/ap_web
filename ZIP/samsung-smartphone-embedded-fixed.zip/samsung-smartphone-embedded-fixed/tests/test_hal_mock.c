#include "galaxy_hal_mock.h"
#include "test_framework.h"
void test_hal_mock_adc_temp_gpio_tick(void){
    galaxy_hal_reset(); galaxy_hal_set_adc_mv(2,3800); galaxy_hal_set_temp_c(1,41.5f); galaxy_hal_set_gpio(7,1); galaxy_hal_advance_ms(25);
    TEST_ASSERT_EQUAL_INT(3800,galaxy_hal_adc_read_mv(2)); TEST_ASSERT_NEAR_FLOAT(41.5f,galaxy_hal_temp_read_c(1),0.001f); TEST_ASSERT_EQUAL_INT(1,galaxy_hal_get_gpio(7)); TEST_ASSERT_EQUAL_INT(25,galaxy_hal_tick_ms());
}
