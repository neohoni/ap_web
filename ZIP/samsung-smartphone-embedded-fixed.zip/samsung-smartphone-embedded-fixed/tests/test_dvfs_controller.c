#include "dvfs_controller.h"
#include "test_framework.h"
void test_dvfs_ai_boost(void){
    GalaxySystemInput input={SOC_EXYNOS,WORKLOAD_ON_DEVICE_AI,55,20,88,36.0f,70.0f,70,0};
    DvfsDecision d=galaxy_dvfs_decide(input);
    TEST_ASSERT_EQUAL_INT(PERF_BOOST,d.npu_level); TEST_ASSERT_TRUE(d.npu_freq_mhz>=1400);
}
void test_dvfs_thermal_throttle(void){
    GalaxySystemInput input={SOC_SNAPDRAGON,WORKLOAD_GAMING,95,95,30,46.0f,90.0f,80,1};
    DvfsDecision d=galaxy_dvfs_decide(input);
    TEST_ASSERT_EQUAL_INT(PERF_LOW,d.cpu_level); TEST_ASSERT_EQUAL_INT(PERF_LOW,d.gpu_level); TEST_ASSERT_EQUAL_INT(PERF_LOW,d.npu_level);
}
