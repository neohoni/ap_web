#include "battery_policy.h"
#include "test_framework.h"
void test_battery_policy_save_mode(void){
    BatteryDecision d=galaxy_battery_decide(15,0,36.0f);
    TEST_ASSERT_EQUAL_INT(BATTERY_MODE_SAVE,d.mode); TEST_ASSERT_EQUAL_INT(60,d.max_display_hz); TEST_ASSERT_TRUE(!d.background_ai_allowed);
}
void test_battery_policy_performance_mode(void){
    BatteryDecision d=galaxy_battery_decide(80,1,35.0f);
    TEST_ASSERT_EQUAL_INT(BATTERY_MODE_PERFORMANCE,d.mode); TEST_ASSERT_EQUAL_INT(120,d.max_display_hz); TEST_ASSERT_TRUE(d.background_ai_allowed);
}
