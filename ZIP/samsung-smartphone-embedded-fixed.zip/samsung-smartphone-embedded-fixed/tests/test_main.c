#include <stdio.h>
#include "test_framework.h"
void test_dvfs_ai_boost(void); void test_dvfs_thermal_throttle(void); void test_thermal_states(void); void test_battery_policy_save_mode(void); void test_battery_policy_performance_mode(void); void test_camera_night_pipeline(void); void test_camera_8k_thermal_limit(void); void test_hal_mock_adc_temp_gpio_tick(void);
int main(void){
    printf("Samsung Smartphone Embedded Test Start\n");
    RUN_TEST(test_dvfs_ai_boost); RUN_TEST(test_dvfs_thermal_throttle); RUN_TEST(test_thermal_states);
    RUN_TEST(test_battery_policy_save_mode); RUN_TEST(test_battery_policy_performance_mode);
    RUN_TEST(test_camera_night_pipeline); RUN_TEST(test_camera_8k_thermal_limit); RUN_TEST(test_hal_mock_adc_temp_gpio_tick);
    printf("All Samsung smartphone embedded tests passed\n"); return 0;
}
