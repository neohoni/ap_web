# Samsung Smartphone Embedded Test Model

삼성 Galaxy급 스마트폰의 임베디드 제어 구조를 모델링한 C 테스트 프로젝트입니다.

실제 삼성 내부 코드가 아니라, 포트폴리오 / 학습 / 제품 시뮬레이션용 portable C 구조입니다.

## 포함 기능

- AP DVFS controller
- CPU/GPU/NPU workload policy
- Thermal throttling manager
- Battery / display / background AI policy
- Camera + AI pipeline decision
- HAL mock
- Unit test
- GitHub Actions CI

## 실행

가장 권장:

```bash
make test
```

shell script:

```bash
chmod +x scripts/run_tests.sh
./scripts/run_tests.sh
```

make가 없는 환경:

```bash
chmod +x scripts/run_tests_no_make.sh
./scripts/run_tests_no_make.sh
```

Windows:

```bat
scripts\run_tests.bat
```

## interpreter file not found 해결

대부분 `scripts/run_tests.sh` 첫 줄의 interpreter 경로 또는 CRLF 줄바꿈 문제입니다.

이 버전은 `#!/bin/sh`로 수정되어 `bash` 의존성을 줄였습니다.

그래도 오류가 나면 아래 명령을 실행하세요.

```bash
sed -i 's/\r$//' scripts/run_tests.sh
sed -i 's/\r$//' scripts/run_tests_no_make.sh
chmod +x scripts/run_tests.sh scripts/run_tests_no_make.sh
make test
```

Termux에서는:

```bash
pkg update
pkg install clang make git
make test
```

Ubuntu/Debian에서는:

```bash
sudo apt update
sudo apt install build-essential make git
make test
```

## GitHub 업로드

```bash
git init
git add .
git commit -m "Add Samsung smartphone embedded test model"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/samsung-smartphone-embedded.git
git push -u origin main
```
