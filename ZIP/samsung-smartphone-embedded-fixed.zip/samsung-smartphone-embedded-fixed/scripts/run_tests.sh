#!/bin/sh
set -eu
make clean
make test
