#!/bin/sh
set -eu
mkdir -p build
gcc -std=c11 -Wall -Wextra -Werror -O2 -Iinclude -Ihal \
  src/dvfs_controller.c src/thermal_manager.c src/battery_policy.c src/camera_ai_pipeline.c \
  hal/galaxy_hal_mock.c \
  tests/test_main.c tests/test_dvfs_controller.c tests/test_thermal_manager.c tests/test_battery_policy.c tests/test_camera_ai_pipeline.c tests/test_hal_mock.c \
  -o build/samsung_embedded_tests
./build/samsung_embedded_tests
