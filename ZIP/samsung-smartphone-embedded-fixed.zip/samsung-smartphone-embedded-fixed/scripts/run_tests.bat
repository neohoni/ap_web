@echo off
make clean
make test
