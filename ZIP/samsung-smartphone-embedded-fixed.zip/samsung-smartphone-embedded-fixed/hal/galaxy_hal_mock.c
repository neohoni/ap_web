#include "galaxy_hal_mock.h"
#define MAX_CHANNELS 16
#define MAX_GPIOS 64
static uint16_t adc_mv[MAX_CHANNELS]; static float temps[MAX_CHANNELS]; static int gpios[MAX_GPIOS]; static uint32_t tick;
void galaxy_hal_reset(void){ tick=0; for(int i=0;i<MAX_CHANNELS;i++){adc_mv[i]=0;temps[i]=25.0f;} for(int i=0;i<MAX_GPIOS;i++)gpios[i]=0; }
void galaxy_hal_set_adc_mv(int c,uint16_t mv){ if(c>=0&&c<MAX_CHANNELS)adc_mv[c]=mv; }
uint16_t galaxy_hal_adc_read_mv(int c){ if(c<0||c>=MAX_CHANNELS)return 0; return adc_mv[c]; }
void galaxy_hal_set_temp_c(int s,float t){ if(s>=0&&s<MAX_CHANNELS)temps[s]=t; }
float galaxy_hal_temp_read_c(int s){ if(s<0||s>=MAX_CHANNELS)return 25.0f; return temps[s]; }
void galaxy_hal_set_gpio(int p,int v){ if(p>=0&&p<MAX_GPIOS)gpios[p]=v?1:0; }
int galaxy_hal_get_gpio(int p){ if(p<0||p>=MAX_GPIOS)return 0; return gpios[p]; }
void galaxy_hal_advance_ms(uint32_t d){ tick+=d; }
uint32_t galaxy_hal_tick_ms(void){ return tick; }
