#ifndef GALAXY_HAL_MOCK_H
#define GALAXY_HAL_MOCK_H
#include <stdint.h>
void galaxy_hal_reset(void);
void galaxy_hal_set_adc_mv(int channel,uint16_t mv);
uint16_t galaxy_hal_adc_read_mv(int channel);
void galaxy_hal_set_temp_c(int sensor,float temp_c);
float galaxy_hal_temp_read_c(int sensor);
void galaxy_hal_set_gpio(int pin,int value);
int galaxy_hal_get_gpio(int pin);
void galaxy_hal_advance_ms(uint32_t delta);
uint32_t galaxy_hal_tick_ms(void);
#endif
