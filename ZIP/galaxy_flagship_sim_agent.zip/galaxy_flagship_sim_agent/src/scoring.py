from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class ScoreBreakdown:
    performance: float
    ai: float
    camera: float
    display: float
    battery_charging: float
    ecosystem: float
    total: float


class FlagshipScorer:
    def __init__(self, weights: Dict[str, float]):
        self.weights = weights

    def score_device(self, spec: Dict[str, Any], year: int) -> ScoreBreakdown:
        performance = self._score_performance(spec, year)
        ai = min(float(spec.get("ai_level", 60)), 100.0)
        camera = self._score_camera(spec)
        display = self._score_display(spec)
        battery_charging = self._score_battery_charging(spec)
        ecosystem = self._score_ecosystem(spec)

        total = (
            performance * self.weights.get("performance", 0.25)
            + ai * self.weights.get("ai", 0.20)
            + camera * self.weights.get("camera", 0.20)
            + display * self.weights.get("display", 0.12)
            + battery_charging * self.weights.get("battery_charging", 0.13)
            + ecosystem * self.weights.get("ecosystem", 0.10)
        )
        return ScoreBreakdown(
            performance=round(performance, 1),
            ai=round(ai, 1),
            camera=round(camera, 1),
            display=round(display, 1),
            battery_charging=round(battery_charging, 1),
            ecosystem=round(ecosystem, 1),
            total=round(total, 1),
        )

    def _score_performance(self, spec: Dict[str, Any], year: int) -> float:
        base_by_year = {
            2023: 78,
            2024: 84,
            2025: 90,
            2026: 94,
            2027: 97,
        }
        base = base_by_year.get(year, 80)
        ap = str(spec.get("ap", "")).lower()
        if "ultra" in spec.get("name", "").lower() or "elite" in ap:
            base += 2
        if "exynos" in ap and "snapdragon" in ap:
            base -= 1
        return max(0, min(base, 100))

    def _score_camera(self, spec: Dict[str, Any]) -> float:
        main_mp = float(spec.get("main_camera_mp", 50))
        ultrawide_mp = float(spec.get("ultrawide_mp", 12))
        telephoto = str(spec.get("telephoto", ""))
        score = 70
        if main_mp >= 200:
            score += 12
        elif main_mp >= 50:
            score += 7
        if ultrawide_mp >= 50:
            score += 6
        if "50MP" in telephoto:
            score += 7
        if "10x" in telephoto or "hybrid" in telephoto.lower():
            score += 4
        return max(0, min(score, 100))

    def _score_display(self, spec: Dict[str, Any]) -> float:
        display = str(spec.get("display", "")).lower()
        score = 80
        if "qhd" in display:
            score += 6
        if "ltpo" in display or "1-120" in display:
            score += 5
        if "anti-reflective" in display or "next-gen" in display:
            score += 4
        return max(0, min(score, 100))

    def _score_battery_charging(self, spec: Dict[str, Any]) -> float:
        battery = float(spec.get("battery_mah", 4000))
        charging = float(spec.get("charging_w", 25))
        score = 60 + min((battery - 3500) / 25, 25) + min(charging / 3, 20)
        return max(0, min(score, 100))

    def _score_ecosystem(self, spec: Dict[str, Any]) -> float:
        features = spec.get("ecosystem_features", [])
        score = 70 + min(len(features) * 5, 25)
        if any("S Pen" in item for item in features):
            score += 5
        return max(0, min(score, 100))
