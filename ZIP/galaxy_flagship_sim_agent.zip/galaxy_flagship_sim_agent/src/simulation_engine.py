from __future__ import annotations

from typing import Dict, Any, List


class SimulationEngine:
    def merge_confirmed_and_simulated(
        self,
        confirmed_specs: Dict[str, Any],
        s27_scenarios: Dict[str, Any],
        scenario: str = "base_case",
    ) -> Dict[str, Any]:
        combined = dict(confirmed_specs)
        s27 = s27_scenarios["S27"]
        if scenario not in s27["scenarios"]:
            available = ", ".join(s27["scenarios"].keys())
            raise ValueError(f"Unknown S27 scenario '{scenario}'. Available: {available}")

        selected = s27["scenarios"][scenario]
        combined["S27"] = {
            "year": s27["year"],
            "status": s27["status"],
            "scenario": scenario,
            "assumption": selected["assumption"],
            "models": selected["models"],
        }
        return combined

    def filter_models(self, specs: Dict[str, Any], target: str) -> Dict[str, Any]:
        if target.lower() == "all":
            return specs
        normalized = target.capitalize()
        if normalized not in {"Base", "Plus", "Ultra"}:
            raise ValueError("target must be one of: Base, Plus, Ultra, all")

        filtered: Dict[str, Any] = {}
        for generation, payload in specs.items():
            if normalized in payload.get("models", {}):
                filtered[generation] = {
                    **payload,
                    "models": {normalized: payload["models"][normalized]},
                }
        return filtered

    def detect_trends(self, specs: Dict[str, Any]) -> List[str]:
        trends = []
        ultra_rows = []
        for generation, payload in specs.items():
            ultra = payload.get("models", {}).get("Ultra")
            if ultra:
                ultra_rows.append((generation, payload.get("year"), ultra))

        if ultra_rows:
            first = ultra_rows[0][2]
            last = ultra_rows[-1][2]
            battery_delta = last.get("battery_mah", 0) - first.get("battery_mah", 0)
            charging_delta = last.get("charging_w", 0) - first.get("charging_w", 0)
            trends.append(f"Ultra battery delta: {battery_delta:+}mAh")
            trends.append(f"Ultra charging delta: {charging_delta:+}W")
            trends.append("Ultra camera track stays premium with 200MP-class main sensor after S23.")
            trends.append("AI score rises sharply from S24 onward due to Galaxy AI and on-device AI assumptions.")
        return trends
