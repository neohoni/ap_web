"""Galaxy Flagship Evolution Simulator Agent package."""
