from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


class DataLoader:
    def __init__(self, root: Path):
        self.root = root
        self.data_dir = root / "data"

    def load_json(self, file_name: str) -> Dict[str, Any]:
        path = self.data_dir / file_name
        if not path.exists():
            raise FileNotFoundError(f"Missing data file: {path}")
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def load_confirmed_specs(self) -> Dict[str, Any]:
        return self.load_json("confirmed_specs.json")

    def load_s27_scenarios(self) -> Dict[str, Any]:
        return self.load_json("s27_scenarios.json")

    def load_config(self) -> Dict[str, Any]:
        path = self.root / "agent_config.json"
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
