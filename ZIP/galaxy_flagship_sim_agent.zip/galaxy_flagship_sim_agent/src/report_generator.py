from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List

from .scoring import ScoreBreakdown


class ReportGenerator:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def build_markdown(
        self,
        specs: Dict[str, Any],
        scores: Dict[str, Dict[str, ScoreBreakdown]],
        trends: List[str],
        user_file_hits: List[Dict[str, Any]],
    ) -> str:
        lines: List[str] = []
        lines.append("# Galaxy S23~S27 Flagship Simulation Report")
        lines.append("")
        lines.append("> S27 data is simulation-only and must not be treated as confirmed specs.")
        lines.append("")
        lines.append("## 1. 핵심 요약")
        lines.append("")
        for trend in trends:
            lines.append(f"- {trend}")
        lines.append("")

        lines.append("## 2. 세대별 스펙 비교")
        lines.append("")
        lines.append("| Generation | Model | Status | Scenario | AP | Camera | Battery | Charging | AI | Total Score |")
        lines.append("|---|---|---|---|---|---:|---:|---:|---:|---:|")
        for generation, payload in specs.items():
            scenario = payload.get("scenario", "-")
            for model_key, spec in payload.get("models", {}).items():
                score = scores[generation][model_key]
                lines.append(
                    f"| {generation} | {spec.get('name')} | {payload.get('status')} | {scenario} | "
                    f"{spec.get('ap')} | {spec.get('main_camera_mp')}MP | {spec.get('battery_mah')}mAh | "
                    f"{spec.get('charging_w')}W | {score.ai} | {score.total} |"
                )
        lines.append("")

        lines.append("## 3. 점수 상세")
        lines.append("")
        lines.append("| Generation | Model | Performance | AI | Camera | Display | Battery/Charging | Ecosystem | Total |")
        lines.append("|---|---|---:|---:|---:|---:|---:|---:|---:|")
        for generation, payload in specs.items():
            for model_key, spec in payload.get("models", {}).items():
                score = scores[generation][model_key]
                lines.append(
                    f"| {generation} | {spec.get('name')} | {score.performance} | {score.ai} | {score.camera} | "
                    f"{score.display} | {score.battery_charging} | {score.ecosystem} | {score.total} |"
                )
        lines.append("")

        lines.append("## 4. 사용자 첨부 파일 검색 결과")
        lines.append("")
        if user_file_hits:
            for hit in user_file_hits:
                lines.append(f"- `{hit['file']}` / score={hit['score']}")
                if hit.get("snippet"):
                    lines.append(f"  - snippet: {hit['snippet'][:300].replace(chr(10), ' ')}")
        else:
            lines.append("- user_files/ 폴더에서 관련 검색 결과가 없습니다.")
        lines.append("")

        lines.append("## 5. 사용상 주의")
        lines.append("")
        lines.append("- S23~S26은 확정 또는 현재 공개 데이터 레이어입니다.")
        lines.append("- S27은 시뮬레이션 레이어입니다.")
        lines.append("- 실제 제품 출시 시점에는 AP, 카메라, 배터리, 충전, AI 기능이 변경될 수 있습니다.")
        return "\n".join(lines)

    def save(self, markdown: str, json_payload: Dict[str, Any]) -> Dict[str, Path]:
        md_path = self.output_dir / "flagship_report.md"
        json_path = self.output_dir / "flagship_report.json"
        md_path.write_text(markdown, encoding="utf-8")
        json_path.write_text(json.dumps(json_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"markdown": md_path, "json": json_path}
