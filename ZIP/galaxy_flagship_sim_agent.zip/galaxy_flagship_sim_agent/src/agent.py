from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Dict, Any

from .data_loader import DataLoader
from .report_generator import ReportGenerator
from .retriever import LocalFileRetriever
from .scoring import FlagshipScorer
from .simulation_engine import SimulationEngine


class GalaxyFlagshipAgent:
    def __init__(self, root: Path):
        self.root = root
        self.loader = DataLoader(root)
        self.config = self.loader.load_config()
        self.engine = SimulationEngine()
        self.scorer = FlagshipScorer(self.config["score_model"])
        self.retriever = LocalFileRetriever(root / "user_files")
        self.reporter = ReportGenerator(root / "outputs")

    def run(self, mode: str = "full", target: str = "Ultra", scenario: str = "base_case", query: str = "Galaxy S Ultra AP camera AI") -> Dict[str, Any]:
        confirmed = self.loader.load_confirmed_specs()
        s27 = self.loader.load_s27_scenarios()

        if mode == "confirmed":
            specs = confirmed
        elif mode == "s27":
            specs = self.engine.merge_confirmed_and_simulated({}, s27, scenario=scenario)
        elif mode == "full":
            specs = self.engine.merge_confirmed_and_simulated(confirmed, s27, scenario=scenario)
        else:
            raise ValueError("mode must be one of: confirmed, s27, full")

        specs = self.engine.filter_models(specs, target)
        trends = self.engine.detect_trends(specs)
        user_file_hits = self.retriever.search(query=query, limit=self.config["retrieval_settings"]["top_k"])

        scores: Dict[str, Dict[str, Any]] = {}
        for generation, payload in specs.items():
            scores[generation] = {}
            for model_key, spec in payload.get("models", {}).items():
                scores[generation][model_key] = self.scorer.score_device(spec, payload.get("year", 2027))

        markdown = self.reporter.build_markdown(specs, scores, trends, user_file_hits)
        json_payload = {
            "agent": self.config["agent_name"],
            "mode": mode,
            "target": target,
            "scenario": scenario,
            "specs": specs,
            "scores": {
                generation: {model: asdict(score) for model, score in model_scores.items()}
                for generation, model_scores in scores.items()
            },
            "trends": trends,
            "user_file_hits": user_file_hits,
        }
        output_paths = self.reporter.save(markdown, json_payload)
        return {
            "markdown": markdown,
            "json_payload": json_payload,
            "output_paths": {k: str(v) for k, v in output_paths.items()},
        }
