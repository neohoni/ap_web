from __future__ import annotations

from pathlib import Path
from typing import List, Dict, Any


class LocalFileRetriever:
    """Simple local file search stub.

    Put TXT, MD, JSON, CSV files in user_files/ and this retriever will search
    file names and plain text contents. Extend VectorRetriever for FAISS/Chroma.
    """

    TEXT_EXTENSIONS = {".txt", ".md", ".json", ".csv", ".yaml", ".yml"}

    def __init__(self, user_files_dir: Path):
        self.user_files_dir = user_files_dir

    def list_files(self) -> List[Path]:
        if not self.user_files_dir.exists():
            return []
        return [p for p in self.user_files_dir.rglob("*") if p.is_file() and p.name != "README.md"]

    def search(self, query: str, limit: int = 8) -> List[Dict[str, Any]]:
        query_lower = query.lower().strip()
        results: List[Dict[str, Any]] = []
        for path in self.list_files():
            score = 0
            if query_lower and query_lower in path.name.lower():
                score += 5
            snippet = ""
            if path.suffix.lower() in self.TEXT_EXTENSIONS:
                try:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    idx = text.lower().find(query_lower) if query_lower else -1
                    if idx >= 0:
                        score += 10
                        snippet = text[max(0, idx - 120): idx + 240]
                except Exception as exc:
                    snippet = f"Could not read file: {exc}"
            if score > 0:
                results.append({"file": str(path), "score": score, "snippet": snippet})
        return sorted(results, key=lambda x: x["score"], reverse=True)[:limit]


class VectorRetriever:
    """Vector DB adapter placeholder.

    Implement methods here for FAISS, Chroma, Pinecone, Qdrant, Weaviate, etc.
    """

    def __init__(self, provider: str | None = None):
        self.provider = provider

    def connect(self) -> None:
        raise NotImplementedError("Connect your vector DB implementation here.")

    def search(self, query: str, top_k: int = 8) -> List[Dict[str, Any]]:
        raise NotImplementedError("Implement vector similarity search here.")
