# Galaxy Flagship Evolution Simulator Agent

Samsung Galaxy S23~S27 플래그십 스마트폰과 AP 전략을 분석하고, S27을 보수형/기준형/공격형 시나리오로 시뮬레이션하는 VSCode용 Python 프로젝트입니다.

## 기능

- S23~S26 확정 스펙 데이터 로딩
- S27 시뮬레이션 시나리오 생성
- Base / Plus / Ultra 모델 비교
- AP, AI, 카메라, 디스플레이, 배터리/충전, 생태계 점수 계산
- 사용자 분석 파일 폴더 `user_files/` 검색 스텁 포함
- Markdown / JSON 결과 출력

## 폴더 구조

```text
.
├── main.py
├── requirements.txt
├── agent_config.json
├── data/
│   ├── confirmed_specs.json
│   └── s27_scenarios.json
├── src/
│   ├── agent.py
│   ├── data_loader.py
│   ├── report_generator.py
│   ├── retriever.py
│   ├── scoring.py
│   └── simulation_engine.py
├── user_files/
│   └── README.md
├── outputs/
└── .vscode/
    ├── launch.json
    └── settings.json
```

## 실행 방법

### 1. 압축 해제 후 VSCode에서 폴더 열기

```bash
cd galaxy_flagship_sim_agent
```

### 2. 가상환경 생성

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

### 3. 의존성 설치

```bash
pip install -r requirements.txt
```

### 4. 실행

전체 시뮬레이션:

```bash
python main.py --mode full --target Ultra
```

S27 기준형 시나리오만 실행:

```bash
python main.py --mode s27 --scenario base_case --target Ultra
```

전체 모델 분석:

```bash
python main.py --mode full --target all
```

## 사용자 분석 파일 첨부

PDF, TXT, MD, CSV, JSON, XLSX 등의 파일을 `user_files/` 폴더에 넣으면 `retriever.py`가 파일 목록과 기본 텍스트 검색을 수행합니다.

현재 버전은 로컬 파일 검색 스텁이며, FAISS/Chroma/Pinecone/Qdrant 연동은 `src/retriever.py`의 `VectorRetriever` 클래스를 확장하면 됩니다.

## 출력 결과

실행 후 결과는 `outputs/` 폴더에 저장됩니다.

- `flagship_report.md`
- `flagship_report.json`

## 데이터 정책

- S23~S26: 확정 데이터 레이어
- S27: 시뮬레이션 레이어
- S27 결과는 항상 `simulation`, `assumption`, `scenario` 필드를 포함합니다.
