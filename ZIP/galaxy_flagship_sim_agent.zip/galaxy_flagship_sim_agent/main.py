from __future__ import annotations

import argparse
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from src.agent import GalaxyFlagshipAgent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Galaxy S23~S27 Flagship Simulation Agent")
    parser.add_argument("--mode", choices=["confirmed", "s27", "full"], default="full")
    parser.add_argument("--target", choices=["Base", "Plus", "Ultra", "all"], default="Ultra")
    parser.add_argument("--scenario", choices=["conservative", "base_case", "aggressive"], default="base_case")
    parser.add_argument("--query", default="Galaxy S Ultra AP camera AI", help="Query for user_files search")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parent
    console = Console()
    agent = GalaxyFlagshipAgent(root=root)
    result = agent.run(mode=args.mode, target=args.target, scenario=args.scenario, query=args.query)

    console.print(Panel.fit("Galaxy Flagship Evolution Simulator Agent", subtitle="Run complete"))
    console.print(result["markdown"])
    console.print("\n[bold]Saved files:[/bold]")
    for kind, path in result["output_paths"].items():
        console.print(f"- {kind}: {path}")


if __name__ == "__main__":
    main()
