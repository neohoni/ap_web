# user_files

여기에 사용자의 분석 파일을 넣으세요.

지원 예시:

- PDF 분석 리포트
- TXT / MD 요약 문서
- CSV / Excel 벤치마크 파일
- JSON 스펙 DB
- 임베딩 메타데이터 파일

현재 기본 구현은 TXT, MD, JSON, CSV, YAML의 파일명/텍스트 검색을 지원합니다.
PDF, Excel, 벡터 DB 검색은 `src/retriever.py`를 확장해서 연결하세요.
