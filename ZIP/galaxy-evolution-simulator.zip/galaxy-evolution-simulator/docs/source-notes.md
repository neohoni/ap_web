# Source Notes

Primary sources used in the dashboard:

- Samsung Mobile Press product spec pages for Galaxy S23/S24/S25/S26.
- Samsung regional Galaxy S26/S26 Ultra spec pages.
- Samsung Support S26 model comparison page.
- Reuters coverage of Galaxy S25 AI/Qualcomm strategy.
- S27 rumors are marked as speculative and should not be treated as confirmed specifications.
