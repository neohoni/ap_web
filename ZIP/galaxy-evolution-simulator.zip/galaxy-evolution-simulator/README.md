# Galaxy S23–S27 Evolution Simulator

Galaxy S23부터 S26 공개 스펙과 S27 보수/기준/공격 시나리오를 비교하는 단일 HTML 대시보드입니다.

## 포함 내용

- S23 전 모델 → S26 전 모델 공개 스펙 비교
- S27 보수/기준/공격 시나리오
- AP 전략 변화
- 카메라 센서/망원 구조 변화
- Galaxy AI 기능 변화
- 배터리/충전/전력 효율 변화
- 종합 플래그십 점수
- GitHub 업로드 명령어

## 사용 방법

```bash
# 로컬에서 바로 열기
open index.html

# 또는 VS Code에서 Live Server 사용
code .
```

## GitHub 업로드

```bash
git init
git add .
git commit -m "Add Galaxy S23-S27 evolution simulator"
git branch -M main
git remote add origin https://github.com/<USER>/galaxy-evolution-simulator.git
git push -u origin main
```

## 주의

- S23~S26은 공개 자료 기반입니다.
- S27은 확정 스펙이 아니라 시뮬레이션입니다.
- 지역별 AP/충전/메모리 구성은 국가·통신사별로 다를 수 있습니다.
