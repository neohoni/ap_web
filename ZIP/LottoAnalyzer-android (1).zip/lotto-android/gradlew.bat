@rem Gradle startup script for Windows
@rem Android Studio가 자동으로 gradle-wrapper.jar을 다운로드합니다.
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
set CLASSPATH=%DIRNAME%\gradle\wrapper\gradle-wrapper.jar
java -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
