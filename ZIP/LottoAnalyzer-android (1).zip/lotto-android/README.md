# 🎱 로또 완전분석기 — Android Studio 빌드 가이드

## ✅ 필요한 것
- Android Studio Hedgehog (2023.1.1) 이상
  → https://developer.android.com/studio

---

## 📦 빌드 순서

### 1. 프로젝트 열기
```
Android Studio 실행
→ File → Open
→ 이 폴더 (lotto-android) 선택
→ OK
```

### 2. Gradle Sync
- 열리면 자동으로 Sync 시작
- 인터넷 연결 필요 (Gradle 8.0 + AGP 8.1.4 자동 다운로드)
- 약 3~5분 소요

### 3. gradle-wrapper.jar 오류 발생 시
```
Help → Find Action → "Add Gradle Wrapper" 실행
또는
Tools → Gradle → Generate Wrapper
```

### 4. APK 빌드
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
완료 후 팝업에서 "locate" 클릭

### 5. APK 위치
```
lotto-android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 폰에 설치

### 방법 A: USB (adb)
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 방법 B: 직접 전송
1. APK 파일을 카카오톡/이메일/USB로 폰 전송
2. 파일 앱에서 APK 탭
3. 설정 → 알 수 없는 앱 설치 → 허용

---

## 🔧 자주 발생하는 오류 해결

| 오류 | 해결 |
|------|------|
| `gradle-wrapper.jar` 없음 | Tools → Gradle → Generate Wrapper |
| `compileSdk` 버전 오류 | File → Project Structure → SDK 위치 확인 |
| Manifest merge 오류 | app/build.gradle → namespace 확인 |
| `AAPT: error` | res 폴더 내 파일명 소문자인지 확인 |

---

## 앱 특징
- WebView 기반 (HTML/JS 앱 그대로)
- localStorage 지원 → 히스토리·캐시 저장
- 인터넷 연결 시 최신 회차 자동 수집
- 오프라인에서도 캐시 데이터로 동작
- 상태바 완전 다크 테마 (#07070E)
- 뒤로가기 버튼 지원
