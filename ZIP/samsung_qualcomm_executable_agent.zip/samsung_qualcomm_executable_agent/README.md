# Samsung Qualcomm Galaxy Architecture Agent

삼성 Galaxy 스마트폰 Qualcomm Snapdragon 라인업과 마이크로아키텍처 분석을 실행 가능한 에이전트로 만든 프로젝트입니다.

## 구성

```text
samsung_qualcomm_executable_agent/
├── backend/                 # Python CLI + FastAPI 실행 에이전트
├── android-app/             # Android Studio에서 여는 앱 프로젝트
├── shared/                  # 공통 knowledge base JSON
└── docs/                    # 구조 설명 문서
```

## 1. Python CLI 실행

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/agent.py "S23 Ultra 분석"
python src/agent.py "S23 vs S25 비교"
python src/agent.py "S27 공격 시뮬레이션"
python src/agent.py "임베디드 전력 DVFS 분석"
```

## 2. API 서버 실행

```bash
cd backend
source .venv/bin/activate
uvicorn src.api:app --reload --host 0.0.0.0 --port 8000
```

API 테스트:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/devices
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"query":"S23 vs S25 비교"}'
```

## 3. 테스트

```bash
cd backend
pytest
```

## 4. Android 앱 실행

1. Android Studio 실행
2. `android-app` 폴더 열기
3. Gradle Sync
4. Emulator 또는 실제 기기 선택
5. Run

앱은 네트워크 없이도 동작합니다. `app/src/main/assets/qualcomm_galaxy_knowledge_base.json`을 읽어 로컬에서 분석합니다.

## 5. Android 앱 사용 예시

입력창에 아래처럼 입력합니다.

```text
S23 Ultra 분석
S23 vs S25 비교
S27 기준 시뮬레이션
S27 공격 시뮬레이션
임베디드 전력 DVFS 분석
```

## 6. GitHub 업로드

```bash
git init
git add .
git commit -m "Add executable Samsung Qualcomm Galaxy architecture agent"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/samsung-qualcomm-agent.git
git push -u origin main
```

## 7. 커스터마이징 포인트

- `shared/qualcomm_galaxy_knowledge_base.json`: 모델/SoC/점수/시나리오 수정
- `backend/src/agent.py`: 분석 로직 강화
- `android-app/.../AgentEngine.java`: Android 로컬 에이전트 로직 강화
- `android-app/.../MainActivity.java`: UI 개선

## 8. 향후 확장

- 벡터 DB 연동: Chroma, FAISS
- LLM API 연동: OpenAI API 또는 로컬 LLM
- Android Room DB 저장
- 모델별 벤치마크 차트
- S27/S28 시나리오 자동 점수화
- 발열/DVFS 시뮬레이터 추가
