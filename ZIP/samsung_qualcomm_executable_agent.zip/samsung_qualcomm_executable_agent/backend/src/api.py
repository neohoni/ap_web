from fastapi import FastAPI
from pydantic import BaseModel
from agent import GalaxyQualcommAgent

app = FastAPI(title="Samsung Qualcomm Galaxy Architecture Agent API")
agent = GalaxyQualcommAgent()

class QueryRequest(BaseModel):
    query: str

@app.get("/health")
def health():
    return {"status": "ok", "agent": "samsung-qualcomm-galaxy-architecture-agent"}

@app.get("/devices")
def devices():
    return {"devices": agent.list_devices()}

@app.post("/ask")
def ask(req: QueryRequest):
    return {"query": req.query, "answer": agent.answer(req.query)}
