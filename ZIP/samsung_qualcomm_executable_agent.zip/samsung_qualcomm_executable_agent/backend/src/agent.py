from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_KB_PATH = ROOT / "shared" / "qualcomm_galaxy_knowledge_base.json"


@dataclass
class Device:
    model: str
    year: int
    soc: str
    process: str
    cpu: str
    gpu: str
    npu_ai: str
    isp: str
    modem: str
    architecture_notes: str
    embedded_focus: List[str]
    scores: Dict[str, int]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Device":
        return cls(**data)


class GalaxyQualcommAgent:
    """Rule-based executable agent for Galaxy Qualcomm architecture analysis."""

    def __init__(self, kb_path: Path | str = DEFAULT_KB_PATH) -> None:
        self.kb_path = Path(kb_path)
        with self.kb_path.open("r", encoding="utf-8") as f:
            self.kb = json.load(f)
        self.devices = [Device.from_dict(item) for item in self.kb["devices"]]
        self.weights = self.kb["score_weights"]

    def list_devices(self) -> List[Dict[str, Any]]:
        return [device.__dict__ for device in self.devices]

    def find_device(self, query: str) -> Optional[Device]:
        q = query.lower().replace("galaxy", "").strip()
        aliases = {
            "s20": "Galaxy S20 Ultra", "s21": "Galaxy S21 Ultra", "s22": "Galaxy S22 Ultra",
            "s23": "Galaxy S23 Ultra", "s24": "Galaxy S24 Ultra", "s25": "Galaxy S25 Ultra", "s26": "Galaxy S26 Ultra",
        }
        for key, model in aliases.items():
            if key in q:
                return next((d for d in self.devices if d.model == model), None)
        for device in self.devices:
            if device.model.lower() in q or device.soc.lower() in q:
                return device
        return None

    def weighted_score(self, device: Device) -> float:
        return round(sum(device.scores[k] * self.weights[k] for k in self.weights), 2)

    def summarize_device(self, query: str) -> str:
        device = self.find_device(query)
        if not device:
            return "대상 모델을 찾지 못했습니다. 예: S23, S24 Ultra, Snapdragon 8 Gen 2처럼 입력하세요."
        focus = "\n".join(f"- {item}" for item in device.embedded_focus)
        return f"""# {device.model} Qualcomm Architecture Summary

- Year: {device.year}
- SoC: {device.soc}
- Process: {device.process}
- CPU: {device.cpu}
- GPU: {device.gpu}
- NPU/AI: {device.npu_ai}
- ISP: {device.isp}
- Modem: {device.modem}
- Weighted Product Score: {self.weighted_score(device)}/100

## Architecture Notes
{device.architecture_notes}

## Embedded/System Design Focus
{focus}
"""

    def compare(self, query: str) -> str:
        matches = re.findall(r"s2[0-9]", query.lower())
        unique = []
        for m in matches:
            if m not in unique:
                unique.append(m)
        devices = [self.find_device(m) for m in unique]
        devices = [d for d in devices if d]
        if len(devices) < 2:
            return "비교할 모델을 2개 이상 입력하세요. 예: S23 vs S25 비교"
        rows = []
        for d in devices:
            rows.append(
                f"| {d.model} | {d.soc} | {d.cpu} | {d.gpu} | {d.npu_ai} | {d.modem} | {self.weighted_score(d)} |"
            )
        return """# Qualcomm Galaxy Comparison

| Model | SoC | CPU | GPU | NPU/AI | Modem | Score |
|---|---|---|---|---|---|---:|
""" + "\n".join(rows) + "\n\n## System Interpretation\n" + self._comparison_interpretation(devices)

    def _comparison_interpretation(self, devices: List[Device]) -> str:
        first, last = devices[0], devices[-1]
        delta = self.weighted_score(last) - self.weighted_score(first)
        return (
            f"{first.model}에서 {last.model}로 갈수록 CPU 중심 성능 경쟁에서 "
            f"NPU/ISP/GPU/모뎀을 포함한 heterogeneous AI platform 경쟁으로 이동합니다. "
            f"가중 종합 점수 변화는 {delta:+.2f}점입니다."
        )

    def s27_simulation(self, mode: str = "baseline") -> str:
        scenarios = self.kb["s27_scenarios"]
        if mode not in scenarios:
            mode = "baseline"
        s = scenarios[mode]
        return f"""# Galaxy S27 Qualcomm Scenario: {mode}

- SoC: {s['soc']}
- CPU: {s['cpu']}
- AI: {s['ai']}
- Camera: {s['camera']}
- Battery/Power: {s['battery']}
- Risk: {s['risk']}

## Agent Judgment
S27 시뮬레이션의 핵심 변수는 Oryon CPU 세대 변화, Hexagon NPU 효율, ISP-NPU-GPU zero-copy pipeline, AI modem 전력 최적화, 그리고 vapor chamber 기반 sustained thermal headroom입니다.
"""

    def embedded_analysis(self) -> str:
        return """# Embedded / DVFS / Thermal Analysis

## Main Control Loop
1. Workload classifier: camera, gaming, generative AI, modem-heavy, idle/background
2. Block routing: CPU / GPU / NPU / ISP / DSP / modem
3. Thermal observer: SoC temperature, skin temperature, battery temperature
4. DVFS governor: per-cluster frequency and voltage policy
5. Power gating: disable unused ISP/GPU/NPU slices
6. Memory policy: minimize DRAM copy, prefer zero-copy shared buffers

## Design Insight
Galaxy Snapdragon 성능은 CPU peak clock보다 sustained thermal policy와 heterogeneous scheduler에 더 크게 좌우됩니다. 특히 온디바이스 AI에서는 INT4/INT8 quantization, memory bandwidth, NPU occupancy, ISP-NPU buffer sharing이 실제 체감 성능을 결정합니다.
"""

    def answer(self, query: str) -> str:
        q = query.lower()
        if "s27" in q or "시뮬" in q or "simulation" in q:
            if "보수" in q or "conservative" in q:
                return self.s27_simulation("conservative")
            if "공격" in q or "aggressive" in q:
                return self.s27_simulation("aggressive")
            return self.s27_simulation("baseline")
        if "비교" in q or "compare" in q or " vs " in q:
            return self.compare(query)
        if "dvfs" in q or "임베디드" in q or "thermal" in q or "전력" in q or "scheduler" in q:
            return self.embedded_analysis()
        return self.summarize_device(query)


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Samsung Qualcomm Galaxy Architecture Agent")
    parser.add_argument("query", nargs="*", help="analysis query")
    args = parser.parse_args()
    agent = GalaxyQualcommAgent()
    query = " ".join(args.query) if args.query else "S25 Ultra 분석"
    print(agent.answer(query))


if __name__ == "__main__":
    main()
