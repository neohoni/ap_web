from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "src"))

from agent import GalaxyQualcommAgent


def test_s23_summary_contains_soc():
    agent = GalaxyQualcommAgent()
    answer = agent.answer("S23 Ultra 분석")
    assert "Snapdragon 8 Gen 2 for Galaxy" in answer


def test_compare_s23_s25():
    agent = GalaxyQualcommAgent()
    answer = agent.answer("S23 vs S25 비교")
    assert "Galaxy S23 Ultra" in answer
    assert "Galaxy S25 Ultra" in answer


def test_s27_baseline():
    agent = GalaxyQualcommAgent()
    answer = agent.answer("S27 기준 시뮬레이션")
    assert "Galaxy S27" in answer
