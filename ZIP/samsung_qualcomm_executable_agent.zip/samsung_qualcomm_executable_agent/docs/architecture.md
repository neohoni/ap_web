# Architecture Notes

## Agent Pipeline

```text
User Query
  -> keyword/router
  -> device lookup or scenario lookup
  -> weighted scoring
  -> architecture interpretation
  -> CLI/API/Android UI response
```

## Core Analysis Axes

1. CPU microarchitecture
2. Adreno GPU architecture
3. Hexagon NPU / AI Engine
4. Spectra ISP
5. Snapdragon X-series modem
6. Memory bandwidth
7. DVFS / power gating
8. Samsung One UI / Galaxy AI optimization

## Weighted Score Formula

```text
score = performance*0.25 + ai*0.25 + camera*0.20 + power_efficiency*0.20 + marketability*0.10
```

## Embedded/System Design Interpretation

The project is designed from the viewpoint of a chip design, embedded algorithm, and system design oriented future product simulator. It treats the smartphone not as a CPU-only device but as a heterogeneous AI system containing CPU, GPU, NPU, ISP, modem, memory, and thermal control blocks.
