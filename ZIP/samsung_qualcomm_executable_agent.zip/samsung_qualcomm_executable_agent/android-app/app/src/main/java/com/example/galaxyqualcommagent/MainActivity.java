package com.example.galaxyqualcommagent;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private AgentEngine agent;
    private TextView output;
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            agent = new AgentEngine(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("Galaxy Qualcomm Architecture Agent");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("S20~S26 Qualcomm 라인업 분석 + S27 시뮬레이션 + 임베디드 DVFS 관점");
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 8, 0, 24);
        root.addView(subtitle);

        input = new EditText(this);
        input.setHint("예: S23 vs S25 비교 / S27 공격 시뮬레이션 / 임베디드 전력 분석");
        input.setSingleLine(false);
        input.setMinLines(2);
        root.addView(input);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, 16, 0, 16);

        Button ask = new Button(this);
        ask.setText("분석 실행");
        ask.setOnClickListener(v -> runQuery(input.getText().toString()));
        buttons.addView(ask, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button scenario = new Button(this);
        scenario.setText("S27 기준");
        scenario.setOnClickListener(v -> runQuery("S27 기준 시뮬레이션"));
        buttons.addView(scenario, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        root.addView(buttons);

        output = new TextView(this);
        output.setTextSize(14);
        output.setTypeface(Typeface.MONOSPACE);
        output.setText(agent.answer("S25 Ultra 분석"));
        output.setPadding(0, 12, 0, 0);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(output);
        root.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
    }

    private void runQuery(String query) {
        if (query == null || query.trim().isEmpty()) query = "S25 Ultra 분석";
        output.setText(agent.answer(query));
    }
}
