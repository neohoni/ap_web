package com.example.galaxyqualcommagent;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class AgentEngine {
    private final JSONObject kb;
    private final JSONArray devices;
    private final JSONObject weights;

    public AgentEngine(Context context) throws Exception {
        InputStream inputStream = context.getAssets().open("qualcomm_galaxy_knowledge_base.json");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) builder.append(line);
        kb = new JSONObject(builder.toString());
        devices = kb.getJSONArray("devices");
        weights = kb.getJSONObject("score_weights");
    }

    public String answer(String query) {
        String q = query.toLowerCase(Locale.ROOT);
        try {
            if (q.contains("s27") || q.contains("시뮬") || q.contains("simulation")) {
                String mode = "baseline";
                if (q.contains("보수") || q.contains("conservative")) mode = "conservative";
                if (q.contains("공격") || q.contains("aggressive")) mode = "aggressive";
                return s27Simulation(mode);
            }
            if (q.contains("비교") || q.contains("compare") || q.contains(" vs ")) return compare(q);
            if (q.contains("dvfs") || q.contains("임베디드") || q.contains("thermal") || q.contains("전력") || q.contains("scheduler")) return embeddedAnalysis();
            JSONObject device = findDevice(q);
            if (device == null) return "대상 모델을 찾지 못했습니다. 예: S23, S24 Ultra, S25 Ultra, S27 시뮬레이션처럼 입력하세요.";
            return summarize(device);
        } catch (Exception e) {
            return "Agent error: " + e.getMessage();
        }
    }

    private JSONObject findDevice(String q) throws Exception {
        String target = null;
        for (int i = 20; i <= 26; i++) {
            if (q.contains("s" + i)) {
                target = "Galaxy S" + i + " Ultra";
                break;
            }
        }
        for (int i = 0; i < devices.length(); i++) {
            JSONObject d = devices.getJSONObject(i);
            if (target != null && d.getString("model").equals(target)) return d;
            if (q.contains(d.getString("soc").toLowerCase(Locale.ROOT))) return d;
        }
        return null;
    }

    private double weightedScore(JSONObject d) throws Exception {
        JSONObject s = d.getJSONObject("scores");
        double total = 0.0;
        total += s.getInt("performance") * weights.getDouble("performance");
        total += s.getInt("ai") * weights.getDouble("ai");
        total += s.getInt("camera") * weights.getDouble("camera");
        total += s.getInt("power_efficiency") * weights.getDouble("power_efficiency");
        total += s.getInt("marketability") * weights.getDouble("marketability");
        return Math.round(total * 100.0) / 100.0;
    }

    private String summarize(JSONObject d) throws Exception {
        StringBuilder focus = new StringBuilder();
        JSONArray arr = d.getJSONArray("embedded_focus");
        for (int i = 0; i < arr.length(); i++) focus.append("- ").append(arr.getString(i)).append("\n");
        return "# " + d.getString("model") + "\n\n" +
                "SoC: " + d.getString("soc") + "\n" +
                "Process: " + d.getString("process") + "\n" +
                "CPU: " + d.getString("cpu") + "\n" +
                "GPU: " + d.getString("gpu") + "\n" +
                "NPU/AI: " + d.getString("npu_ai") + "\n" +
                "ISP: " + d.getString("isp") + "\n" +
                "Modem: " + d.getString("modem") + "\n" +
                "Weighted Score: " + weightedScore(d) + "/100\n\n" +
                "Architecture Notes:\n" + d.getString("architecture_notes") + "\n\n" +
                "Embedded Focus:\n" + focus;
    }

    private String compare(String q) throws Exception {
        StringBuilder table = new StringBuilder("# Comparison\n\n");
        int count = 0;
        for (int i = 20; i <= 26; i++) {
            if (q.contains("s" + i)) {
                JSONObject d = findDevice("s" + i);
                if (d != null) {
                    count++;
                    table.append(d.getString("model")).append("\n")
                            .append("- SoC: ").append(d.getString("soc")).append("\n")
                            .append("- CPU: ").append(d.getString("cpu")).append("\n")
                            .append("- NPU: ").append(d.getString("npu_ai")).append("\n")
                            .append("- Modem: ").append(d.getString("modem")).append("\n")
                            .append("- Score: ").append(weightedScore(d)).append("/100\n\n");
                }
            }
        }
        if (count < 2) return "비교할 모델을 2개 이상 입력하세요. 예: S23 vs S25 비교";
        table.append("System Interpretation:\nCPU 중심 경쟁에서 NPU/ISP/GPU/모뎀 통합 heterogeneous AI platform 경쟁으로 이동합니다.");
        return table.toString();
    }

    private String s27Simulation(String mode) throws Exception {
        JSONObject s = kb.getJSONObject("s27_scenarios").getJSONObject(mode);
        return "# Galaxy S27 Qualcomm Scenario: " + mode + "\n\n" +
                "SoC: " + s.getString("soc") + "\n" +
                "CPU: " + s.getString("cpu") + "\n" +
                "AI: " + s.getString("ai") + "\n" +
                "Camera: " + s.getString("camera") + "\n" +
                "Battery/Power: " + s.getString("battery") + "\n" +
                "Risk: " + s.getString("risk") + "\n\n" +
                "Agent Judgment:\nOryon CPU, Hexagon NPU, ISP-NPU-GPU zero-copy pipeline, AI modem, vapor chamber thermal headroom이 핵심 변수입니다.";
    }

    private String embeddedAnalysis() {
        return "# Embedded / DVFS / Thermal Analysis\n\n" +
                "1. Workload classifier: camera, gaming, generative AI, modem-heavy, idle/background\n" +
                "2. Block routing: CPU / GPU / NPU / ISP / DSP / modem\n" +
                "3. Thermal observer: SoC, skin, battery temperature\n" +
                "4. DVFS governor: per-cluster frequency and voltage policy\n" +
                "5. Power gating: disable unused ISP/GPU/NPU slices\n" +
                "6. Memory policy: zero-copy shared buffers\n\n" +
                "Design Insight:\nGalaxy Snapdragon 성능은 CPU peak clock보다 sustained thermal policy와 heterogeneous scheduler에 크게 좌우됩니다.";
    }
}
