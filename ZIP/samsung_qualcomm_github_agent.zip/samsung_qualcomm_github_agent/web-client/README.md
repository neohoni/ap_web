# Web Client Extension

FastAPI `/ask` 엔드포인트를 호출하는 React/Vue/HTML 클라이언트를 추가할 수 있는 확장 폴더입니다.
