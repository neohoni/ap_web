from backend.src.agent import GalaxyQualcommAgent

def test_agent_lineup():
    agent = GalaxyQualcommAgent()
    answer = agent.ask("라인업")
    assert "Snapdragon" in answer
    assert "Galaxy S23" in answer

def test_compare():
    agent = GalaxyQualcommAgent()
    answer = agent.ask("S23 vs S25 비교")
    assert "Oryon" in answer
    assert "Cortex" in answer

def test_s27():
    agent = GalaxyQualcommAgent()
    answer = agent.ask("S27 공격 시뮬레이션")
    assert "S27_aggressive" in answer
    assert "NPU" in answer
