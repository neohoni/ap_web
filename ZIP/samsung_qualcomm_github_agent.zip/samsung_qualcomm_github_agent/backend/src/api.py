from __future__ import annotations

from pydantic import BaseModel
from fastapi import FastAPI

from .agent import GalaxyQualcommAgent

app = FastAPI(title="Samsung Qualcomm Galaxy Architecture Agent", version="1.0.0")
agent = GalaxyQualcommAgent()

class AskRequest(BaseModel):
    query: str

class AskResponse(BaseModel):
    answer: str

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "agent": "samsung-qualcomm-galaxy"}

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest) -> AskResponse:
    return AskResponse(answer=agent.ask(req.query))
