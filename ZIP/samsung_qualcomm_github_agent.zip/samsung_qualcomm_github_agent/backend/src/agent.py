#!/usr/bin/env python3
"""Samsung Qualcomm Galaxy Architecture Agent.

Rule-based executable agent for GitHub/VSCode demos.
It analyzes Samsung Galaxy Qualcomm Snapdragon lineups, microarchitecture,
embedded power behavior, and future S27 scenarios.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_KB = ROOT / "shared" / "qualcomm_galaxy_knowledge_base.json"


@dataclass
class ModelSpec:
    model: str
    year: int
    soc: str
    cpu: str
    gpu: str
    npu: str
    isp: str
    modem: str
    process: str
    notes: List[str]


class GalaxyQualcommAgent:
    def __init__(self, kb_path: Path | str = DEFAULT_KB) -> None:
        self.kb_path = Path(kb_path)
        if not self.kb_path.exists():
            raise FileNotFoundError(f"Knowledge base not found: {self.kb_path}")
        self.kb: Dict[str, Any] = json.loads(self.kb_path.read_text(encoding="utf-8"))
        self.models: List[ModelSpec] = [ModelSpec(**m) for m in self.kb["models"]]

    def ask(self, query: str) -> str:
        q = query.lower().strip()
        if not q:
            return self.help()
        if any(k in q for k in ["help", "도움", "사용법"]):
            return self.help()
        if any(k in q for k in ["트리", "tree", "구조"]):
            return self.project_tree()
        if any(k in q for k in ["비교", "compare", " vs ", "대비"]):
            return self.compare_from_query(query)
        if any(k in q for k in ["s27", "시뮬", "simulation", "예측", "공격", "기준", "보수"]):
            return self.simulate_s27(query)
        if any(k in q for k in ["dvfs", "전력", "발열", "thermal", "배터리", "power", "scheduler", "스케줄"]):
            return self.embedded_power_analysis(query)
        if any(k in q for k in ["점수", "score", "평가", "market", "시장"]):
            return self.score_summary()
        matched = self.find_models(query)
        if matched:
            return "\n\n".join(self.format_model(m) for m in matched)
        return self.lineup_summary()

    def find_models(self, query: str) -> List[ModelSpec]:
        q = query.lower()
        found: List[ModelSpec] = []
        for m in self.models:
            candidates = [m.model, m.soc, str(m.year)]
            short = m.model.lower().replace("galaxy", "").replace("ultra", "").strip()
            candidates.append(short)
            if any(c.lower() in q for c in candidates if c):
                found.append(m)
        # Korean common compact names
        for key, year in [("s20", 2020),("s21",2021),("s22",2022),("s23",2023),("s24",2024),("s25",2025),("s26",2026)]:
            if key in q:
                found.extend([m for m in self.models if m.year == year])
        # de-duplicate
        dedup = []
        seen = set()
        for m in found:
            if m.model not in seen:
                dedup.append(m); seen.add(m.model)
        return dedup

    def compare_from_query(self, query: str) -> str:
        models = self.find_models(query)
        if len(models) < 2:
            # default useful comparison
            models = [m for m in self.models if m.year in (2023, 2025)]
        lines = ["# Galaxy Qualcomm SoC 비교", ""]
        for m in models[:4]:
            lines += [f"## {m.model}", f"- SoC: {m.soc}", f"- CPU: {m.cpu}", f"- GPU: {m.gpu}", f"- NPU/AI: {m.npu}", f"- ISP: {m.isp}", f"- Modem: {m.modem}", f"- Process: {m.process}", ""]
        lines += ["## 설계 관점 차이", "- Cortex 기반 세대는 Prime/Big/Little 스케줄링과 발열 제어가 핵심입니다.", "- Oryon 기반 세대는 Qualcomm custom CPU 프론트엔드, 캐시, sustained performance, NPU 연동성이 핵심입니다.", "- 실제 제품 경쟁력은 CPU peak보다 ISP/NPU/GPU/modem/DVFS 통합 최적화에 더 크게 좌우됩니다."]
        return "\n".join(lines)

    def format_model(self, m: ModelSpec) -> str:
        notes = "\n".join(f"- {n}" for n in m.notes)
        return f"""# {m.model}
- Year: {m.year}
- SoC: {m.soc}
- CPU: {m.cpu}
- GPU: {m.gpu}
- NPU/AI: {m.npu}
- ISP: {m.isp}
- Modem: {m.modem}
- Process: {m.process}

## 핵심 포인트
{notes}

## 임베디드/칩 설계 관점
- CPU 클러스터별 scheduler policy와 DVFS table이 체감 성능을 좌우합니다.
- ISP/NPU/GPU 간 memory copy를 줄이는 pipeline이 카메라 AI와 배터리에 중요합니다.
- 모뎀 RF 전력 상승은 SoC thermal headroom을 줄일 수 있습니다."""

    def lineup_summary(self) -> str:
        lines = ["# Samsung Galaxy Qualcomm Lineup", ""]
        for m in self.models:
            lines.append(f"- {m.model}: {m.soc} | {m.cpu} | {m.gpu} | {m.modem}")
        lines += ["", "## 핵심 진화", "CPU 중심 AP → GPU/ISP 강화 → AI Engine 통합 → Snapdragon for Galaxy → Oryon custom CPU 기반 heterogeneous AI SoC"]
        return "\n".join(lines)

    def embedded_power_analysis(self, query: str) -> str:
        return """# Embedded Power / DVFS Analysis

## 핵심 병목
- Prime CPU 고클럭은 순간 성능을 올리지만 thermal saturation을 빠르게 유발할 수 있습니다.
- NPU/ISP/GPU가 동시에 동작하는 카메라 AI workload에서는 memory bandwidth와 power domain control이 중요합니다.
- 5G 약전계 환경에서는 modem/RF 전력이 상승하여 CPU/GPU/NPU headroom을 줄일 수 있습니다.

## 권장 분석 포인트
1. DVFS governor: burst 성능보다 sustained 성능 중심으로 평가
2. Scheduler: Prime/Performance/Efficiency core에 workload 분산
3. ISP-NPU-GPU zero-copy: 카메라/AI 후처리의 메모리 이동 최소화
4. Thermal policy: vapor chamber, skin temperature limit, throttling curve
5. Battery model: AI workload별 mW/token, mW/frame, mW/inference 측정

## S27 가정 최적화
- predictive scheduler
- per-block power gating
- AI modem state-aware workload throttling
- INT4/INT8 quantization 중심 NPU 효율 최적화"""

    def simulate_s27(self, query: str) -> str:
        q = query.lower()
        scenario_key = "S27_base"
        if any(k in q for k in ["보수", "conservative"]): scenario_key = "S27_conservative"
        if any(k in q for k in ["공격", "aggressive"]): scenario_key = "S27_aggressive"
        s = self.kb["simulation_scenarios"][scenario_key]
        return f"""# Galaxy S27 Qualcomm Scenario: {scenario_key}

- CPU: {s['cpu']}
- GPU: {s['gpu']}
- NPU/AI: {s['npu']}
- Camera/ISP: {s['camera']}
- Battery/Power: {s['battery']}
- Main Risk: {s['risk']}

## 제품 시뮬레이션 해석
S27 세대는 Oryon CPU 자체 성능보다 NPU, ISP, GPU, modem, thermal policy를 통합한 heterogeneous AI platform 완성도가 중요합니다.
칩 설계/임베디드 알고리즘 관점에서는 workload-aware DVFS와 zero-copy AI camera pipeline이 가장 큰 차별점입니다."""

    def score_summary(self) -> str:
        weights = self.kb["scoring_weights"]
        lines = ["# Product Competitiveness Score Model", ""]
        for k, v in weights.items():
            lines.append(f"- {k}: {v:.0%}")
        lines += ["", "## 평가 방식", "Total = performance + AI + camera + battery_efficiency + marketability", "S25~S27 평가는 peak benchmark보다 sustained performance와 on-device AI 효율을 더 크게 반영해야 합니다."]
        return "\n".join(lines)

    def project_tree(self) -> str:
        return """samsung_qualcomm_github_agent/
├── README.md
├── shared/qualcomm_galaxy_knowledge_base.json
├── backend/
│   ├── requirements.txt
│   ├── src/agent.py
│   ├── src/api.py
│   └── tests/test_agent.py
├── android-app/
│   └── app/src/main/...
├── docs/architecture.md
├── scripts/run_cli.sh
├── scripts/run_api.sh
├── Dockerfile
└── .github/workflows/test.yml"""

    def help(self) -> str:
        return """# 사용법
python backend/src/agent.py "S23 vs S25 비교"
python backend/src/agent.py "S27 공격 시뮬레이션"
python backend/src/agent.py "임베디드 전력 DVFS 분석"
python backend/src/agent.py "제품 경쟁력 점수 평가"
"""


def main() -> None:
    query = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "help"
    agent = GalaxyQualcommAgent()
    print(agent.ask(query))


if __name__ == "__main__":
    main()
