# Architecture Notes

## Agent Pipeline

```text
User Query
→ Intent Detection
→ Knowledge Base Lookup
→ Scenario/Comparison/Power Analysis
→ Markdown/Text Answer
```

## SoC Analysis Axes

- CPU microarchitecture: Cortex generation vs Oryon custom CPU
- GPU: Adreno graphics and compute capability
- NPU: Hexagon AI Engine, INT4/INT8 efficiency, on-device AI
- ISP: Spectra pipeline, AI camera, semantic segmentation
- Modem: X-series modem, RF power, weak-signal battery behavior
- Embedded policy: scheduler, DVFS, thermal throttling, power gating

## Future Extension

- Vector DB retrieval for patents, papers, benchmarks
- LLM API integration
- Android Retrofit API client
- Report generation to Markdown/PDF
