# Vector DB Extension

추후 특허 PDF, 벤치마크 문서, 제품 분석 파일을 벡터 DB로 연동할 때 사용하는 확장 폴더입니다.

권장 구조:

```text
vector/
├── ingest.py
├── embedder.py
├── retriever.py
└── chroma_db/
```
