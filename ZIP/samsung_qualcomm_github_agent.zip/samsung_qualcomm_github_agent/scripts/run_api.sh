#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../backend"
uvicorn src.api:app --reload --host 0.0.0.0 --port 8000
