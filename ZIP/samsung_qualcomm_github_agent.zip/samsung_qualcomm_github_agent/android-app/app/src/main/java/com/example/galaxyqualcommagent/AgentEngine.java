package com.example.galaxyqualcommagent;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class AgentEngine {
    private final JSONObject kb;

    public AgentEngine(Context context) throws Exception {
        InputStream is = context.getAssets().open("qualcomm_galaxy_knowledge_base.json");
        byte[] buffer = new byte[is.available()];
        is.read(buffer);
        is.close();
        kb = new JSONObject(new String(buffer, StandardCharsets.UTF_8));
    }

    public String ask(String query) {
        String q = query == null ? "" : query.toLowerCase();
        if (q.contains("s27") || q.contains("시뮬") || q.contains("공격") || q.contains("기준") || q.contains("보수")) return simulateS27(q);
        if (q.contains("비교") || q.contains("vs") || q.contains("대비")) return compare(q);
        if (q.contains("dvfs") || q.contains("전력") || q.contains("발열") || q.contains("배터리")) return powerAnalysis();
        return lineup();
    }

    private String lineup() {
        StringBuilder sb = new StringBuilder("Samsung Galaxy Qualcomm Lineup\n\n");
        JSONArray models = kb.optJSONArray("models");
        for (int i = 0; i < models.length(); i++) {
            JSONObject m = models.optJSONObject(i);
            sb.append("- ").append(m.optString("model")).append(": ")
              .append(m.optString("soc")).append(" | ")
              .append(m.optString("cpu")).append("\n");
        }
        return sb.toString();
    }

    private String compare(String q) {
        StringBuilder sb = new StringBuilder("Galaxy Qualcomm SoC Compare\n\n");
        JSONArray models = kb.optJSONArray("models");
        for (int i = 0; i < models.length(); i++) {
            JSONObject m = models.optJSONObject(i);
            String model = m.optString("model").toLowerCase();
            if (q.contains("s" + String.valueOf(m.optInt("year")).substring(2)) || q.contains("vs")) {
                sb.append(m.optString("model")).append("\n")
                  .append("SoC: ").append(m.optString("soc")).append("\n")
                  .append("CPU: ").append(m.optString("cpu")).append("\n")
                  .append("GPU: ").append(m.optString("gpu")).append("\n")
                  .append("NPU: ").append(m.optString("npu")).append("\n\n");
            }
        }
        sb.append("Design View: Cortex generation focuses on scheduler/DVFS. Oryon generation focuses on custom CPU, sustained performance, NPU and ISP integration.");
        return sb.toString();
    }

    private String simulateS27(String q) {
        String key = "S27_base";
        if (q.contains("공격")) key = "S27_aggressive";
        if (q.contains("보수")) key = "S27_conservative";
        JSONObject s = kb.optJSONObject("simulation_scenarios").optJSONObject(key);
        return "Galaxy S27 Scenario: " + key + "\n\n" +
                "CPU: " + s.optString("cpu") + "\n" +
                "GPU: " + s.optString("gpu") + "\n" +
                "NPU: " + s.optString("npu") + "\n" +
                "Camera: " + s.optString("camera") + "\n" +
                "Battery: " + s.optString("battery") + "\n" +
                "Risk: " + s.optString("risk");
    }

    private String powerAnalysis() {
        return "Embedded Power / DVFS Analysis\n\n" +
                "- Prime CPU high clock improves burst but can reduce sustained performance.\n" +
                "- ISP/NPU/GPU camera AI workloads require memory-copy reduction.\n" +
                "- Modem RF power can reduce thermal headroom.\n" +
                "- Recommended: workload-aware DVFS, predictive scheduler, per-block power gating, INT4/INT8 NPU optimization.";
    }
}
