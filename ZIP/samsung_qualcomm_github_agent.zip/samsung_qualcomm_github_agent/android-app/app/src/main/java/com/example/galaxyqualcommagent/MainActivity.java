package com.example.galaxyqualcommagent;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    private AgentEngine engine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText input = findViewById(R.id.queryInput);
        Button button = findViewById(R.id.askButton);
        TextView result = findViewById(R.id.resultText);
        try {
            engine = new AgentEngine(this);
            result.setText(engine.ask("라인업"));
        } catch (Exception e) {
            result.setText("Failed to load agent: " + e.getMessage());
        }
        button.setOnClickListener(v -> result.setText(engine.ask(input.getText().toString())));
    }
}
