# Samsung Qualcomm Galaxy Architecture Agent

삼성 Galaxy 스마트폰의 Qualcomm Snapdragon 라인업과 마이크로아키텍처를 분석하는 실행형 에이전트 프로젝트입니다.

이 프로젝트는 다음 관점으로 구성되었습니다.

```text
칩 설계 + 임베디드 알고리즘 + 시스템 설계 + 미래 제품 시뮬레이션
```

분석 대상은 Galaxy S20~S26 Qualcomm Snapdragon 계보이며, S27 미래 시나리오도 포함합니다.

---

## 1. Overview

이 에이전트는 Samsung Galaxy 플래그십에 탑재된 Qualcomm Snapdragon SoC를 다음 기준으로 분석합니다.

- CPU microarchitecture
- Adreno GPU
- Hexagon NPU / AI Engine
- Spectra ISP / camera pipeline
- X-series modem-RF
- DVFS / scheduler / thermal policy
- battery efficiency
- marketability
- S27 future product simulation

---

## 2. Features

```text
1. S20~S26 Galaxy Qualcomm 라인업 요약
2. S23 vs S25 등 세대별 SoC 비교
3. CPU/GPU/NPU/ISP/모뎀 내부 구조 분석
4. 임베디드 전력, DVFS, 발열 관점 분석
5. S27 보수/기준/공격 시나리오 생성
6. FastAPI 서버 실행
7. Android 앱 실행
8. GitHub Actions 테스트 자동화
9. Docker 배포 확장
10. Vector DB / LLM API 추가 연동 가능
```

---

## 3. Project Tree

```text
samsung_qualcomm_github_agent/
├── README.md
├── Dockerfile
├── shared/
│   └── qualcomm_galaxy_knowledge_base.json
├── backend/
│   ├── __init__.py
│   ├── requirements.txt
│   ├── src/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   └── api.py
│   └── tests/
│       └── test_agent.py
├── android-app/
│   ├── settings.gradle
│   ├── build.gradle
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── assets/
│           │   └── qualcomm_galaxy_knowledge_base.json
│           ├── java/com/example/galaxyqualcommagent/
│           │   ├── MainActivity.java
│           │   └── AgentEngine.java
│           └── res/
│               ├── layout/activity_main.xml
│               └── values/styles.xml
├── docs/
│   └── architecture.md
├── scripts/
│   ├── run_cli.sh
│   └── run_api.sh
├── vector/
│   └── README.md
├── web-client/
│   └── README.md
└── .github/
    └── workflows/test.yml
```

---

## 4. Requirements

### Python Backend

```text
Python 3.10+
Git
VSCode
pip
```

### Android App

```text
Android Studio
JDK 17+
Android Gradle Plugin 8.x
Android SDK 35 권장
minSdk 24+
```

### Optional

```text
Docker
GitHub CLI
Postman 또는 curl
```

---

## 5. Installation

압축 해제 후 프로젝트 폴더로 이동합니다.

```bash
unzip samsung_qualcomm_github_agent.zip
cd samsung_qualcomm_github_agent
```

Python 가상환경 생성:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows PowerShell:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

---

## 6. Run

### 6.1 Python CLI 실행

```bash
cd backend
source .venv/bin/activate
python src/agent.py "S23 vs S25 비교"
```

실행 예시:

```bash
python src/agent.py "라인업 정리"
python src/agent.py "S23 Ultra 분석"
python src/agent.py "S23 vs S25 비교"
python src/agent.py "S27 기준 시뮬레이션"
python src/agent.py "S27 공격 시뮬레이션"
python src/agent.py "임베디드 전력 DVFS 분석"
python src/agent.py "제품 경쟁력 점수 평가"
```

루트 폴더에서 스크립트로 실행:

```bash
chmod +x scripts/run_cli.sh
./scripts/run_cli.sh "S27 공격 시뮬레이션"
```

---

### 6.2 FastAPI 서버 실행

```bash
cd backend
source .venv/bin/activate
uvicorn src.api:app --reload --host 0.0.0.0 --port 8000
```

또는 루트 폴더에서:

```bash
chmod +x scripts/run_api.sh
./scripts/run_api.sh
```

브라우저에서 확인:

```text
http://127.0.0.1:8000/health
http://127.0.0.1:8000/docs
```

---

### 6.3 API 테스트

Health check:

```bash
curl http://127.0.0.1:8000/health
```

질문 요청:

```bash
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"query":"S23 vs S25 비교"}'
```

S27 시뮬레이션:

```bash
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"query":"S27 공격 시뮬레이션"}'
```

---

### 6.4 VSCode 실행법

```text
1. VSCode 실행
2. File → Open Folder
3. samsung_qualcomm_github_agent 폴더 선택
4. Terminal → New Terminal
5. cd backend
6. python3 -m venv .venv
7. source .venv/bin/activate
8. pip install -r requirements.txt
9. python src/agent.py "S23 vs S25 비교"
```

추천 VSCode 확장:

```text
Python
Pylance
GitLens
REST Client
```

---

### 6.5 Android 앱 실행법

```text
1. Android Studio 실행
2. Open 선택
3. android-app 폴더 열기
4. Gradle Sync 실행
5. Emulator 또는 실제 Android 기기 선택
6. Run 클릭
```

앱 입력 예시:

```text
라인업 정리
S23 vs S25 비교
S27 기준 시뮬레이션
S27 공격 시뮬레이션
임베디드 전력 DVFS 분석
```

현재 Android 앱은 네트워크 없이 `assets/qualcomm_galaxy_knowledge_base.json`를 로컬로 읽어 동작합니다.

---

## 7. Test

```bash
cd backend
source .venv/bin/activate
PYTHONPATH=.. pytest tests
```

루트 폴더에서 실행:

```bash
PYTHONPATH=. pytest backend/tests
```

---

## 8. Additional Integration Guide

### 8.1 JSON Knowledge Base 연동

공통 지식베이스 파일:

```text
shared/qualcomm_galaxy_knowledge_base.json
```

Android 앱용 복사본:

```text
android-app/app/src/main/assets/qualcomm_galaxy_knowledge_base.json
```

새 모델 추가 예시:

```json
{
  "model": "Galaxy S27 Ultra",
  "year": 2027,
  "soc": "Snapdragon next for Galaxy",
  "cpu": "Next Oryon CPU",
  "gpu": "Next Adreno GPU",
  "npu": "Next Hexagon NPU",
  "isp": "AI computational ISP",
  "modem": "Next X-series modem",
  "process": "next 3nm / 2nm-class",
  "notes": [
    "on-device multimodal AI",
    "zero-copy ISP-NPU-GPU pipeline",
    "predictive DVFS"
  ]
}
```

수정 후 Python은 바로 반영됩니다. Android는 assets 파일도 동일하게 업데이트해야 합니다.

---

### 8.2 FastAPI 연동

백엔드 API 구조:

```text
GET  /health
POST /ask
```

외부 앱이나 웹에서 `/ask`로 질문을 보내면 됩니다.

Request:

```json
{
  "query": "S27 Ultra 공격 시나리오 분석"
}
```

Response:

```json
{
  "answer": "..."
}
```

---

### 8.3 Android 앱과 API 서버 연동

현재 앱은 로컬 JSON 기반입니다. 서버형으로 확장하려면 다음 구조로 바꾸면 됩니다.

```text
Android App
→ Retrofit 또는 OkHttp
→ FastAPI /ask
→ Agent Engine
→ shared JSON
→ Response
```

추가할 Gradle 의존성 예시:

```gradle
implementation "com.squareup.okhttp3:okhttp:4.12.0"
```

Android에서 호출할 주소:

```text
Emulator: http://10.0.2.2:8000/ask
실제 기기: http://<PC_LOCAL_IP>:8000/ask
```

---

### 8.4 Vector DB 연동

특허 PDF, 벤치마크 문서, 제품 분석 파일을 추가하려면 `vector/` 폴더를 확장합니다.

추천 구조:

```text
vector/
├── ingest.py
├── embedder.py
├── retriever.py
└── chroma_db/
```

권장 DB:

```text
ChromaDB
FAISS
LanceDB
SQLite + embedding
```

연동 흐름:

```text
PDF / Markdown / JSON
→ chunking
→ embedding
→ vector DB
→ retrieval
→ agent answer
```

---

### 8.5 LLM API 연동

현재 코드는 룰 기반 에이전트입니다. LLM API를 붙이면 더 자연스러운 답변 생성이 가능합니다.

확장 구조:

```text
User Query
→ Intent Classifier
→ Knowledge Retriever
→ LLM API
→ Structured Answer
→ Report Generator
```

추가 파일 예시:

```text
backend/src/llm_client.py
backend/src/retriever.py
backend/src/report_generator.py
```

---

### 8.6 GitHub Actions 연동

이미 포함된 파일:

```text
.github/workflows/test.yml
```

GitHub에 push하면 자동으로 Python 테스트가 실행됩니다.

---

### 8.7 Docker 연동

빌드:

```bash
docker build -t samsung-qualcomm-agent .
```

실행:

```bash
docker run -p 8000:8000 samsung-qualcomm-agent
```

확인:

```bash
curl http://127.0.0.1:8000/health
```

---

## 9. GitHub Upload Guide

새 GitHub 저장소를 먼저 생성합니다.

예시 저장소 이름:

```text
samsung-qualcomm-galaxy-agent
```

업로드 명령어:

```bash
git init
git add .
git commit -m "Add Samsung Qualcomm Galaxy architecture agent"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/samsung-qualcomm-galaxy-agent.git
git push -u origin main
```

이미 remote가 있을 때 변경:

```bash
git remote set-url origin https://github.com/<YOUR_USERNAME>/samsung-qualcomm-galaxy-agent.git
git push -u origin main
```

Git username 오류 해결:

```bash
git config --global user.name "<YOUR_NAME>"
git config --global user.email "<YOUR_EMAIL>"
```

브랜치 오류 해결:

```bash
git branch -M main
```

---

## 10. Troubleshooting

### ModuleNotFoundError 발생

루트 폴더에서 다음처럼 실행합니다.

```bash
PYTHONPATH=. pytest backend/tests
```

또는 backend 폴더에서 CLI만 실행합니다.

```bash
cd backend
python src/agent.py "라인업"
```

### uvicorn 명령어 없음

```bash
cd backend
source .venv/bin/activate
pip install -r requirements.txt
```

### Android Gradle Sync 실패

```text
1. Android Studio 최신 버전 확인
2. JDK 17 사용 확인
3. File → Sync Project with Gradle Files
4. Build → Clean Project
5. Build → Rebuild Project
```

### 실제 Android 기기에서 API 서버 연결 실패

```text
- PC와 스마트폰이 같은 Wi-Fi에 연결되어 있는지 확인
- uvicorn 실행 시 --host 0.0.0.0 사용
- Android에서는 127.0.0.1 대신 PC의 로컬 IP 사용
```

---

## 11. Roadmap

```text
1. S27/S28 예측 모델 고도화
2. Qualcomm vs Exynos 비교 모듈 추가
3. 특허 PDF 기반 RAG 검색 추가
4. 벤치마크 CSV/JSON 자동 수집
5. Android Retrofit API client 추가
6. 웹 대시보드 추가
7. Markdown/PDF 리포트 자동 생성
8. 제품 경쟁력 점수 시각화
9. GitHub Pages 문서화
10. 온디바이스 LLM 시뮬레이션 모듈 추가
```

---

## 12. License

Research and educational use. 필요하면 MIT License 파일을 추가해서 공개 프로젝트로 확장할 수 있습니다.
