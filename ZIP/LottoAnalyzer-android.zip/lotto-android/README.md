# 🎱 로또 완전분석기 — Android 빌드 가이드

## 빌드 방법 (Android Studio 사용)

### 1단계: Android Studio 설치
- https://developer.android.com/studio 에서 다운로드

### 2단계: 프로젝트 열기
1. Android Studio 실행
2. **File → Open** → 이 폴더(lotto-android) 선택
3. Gradle Sync 완료까지 대기 (약 2~5분, 인터넷 필요)

### 3단계: APK 빌드
- **메뉴 → Build → Build Bundle(s) / APK(s) → Build APK(s)**
- 완료 후 `app/build/outputs/apk/debug/app-debug.apk` 생성

### 4단계: 폰에 설치
```
# USB 연결 후
adb install app/build/outputs/apk/debug/app-debug.apk
```
또는 APK 파일을 폰으로 전송 후 직접 설치

---

## 릴리즈 APK (서명 버전) 빌드
1. **Build → Generate Signed Bundle / APK**
2. keystore 생성 → APK 선택 → release 빌드

---

## 앱 구조
```
app/src/main/
├── assets/index.html      ← 로또 분석 웹앱 (전체 기능)
├── java/.../MainActivity.java  ← WebView 래퍼
└── res/                   ← 아이콘, 테마 등
```

## 특징
- localStorage 지원 (히스토리, 캐시 저장)
- 인터넷 연결 시 최신 회차 자동 수집
- 오프라인에서도 캐시 데이터로 동작
- 상태바 완전 다크 테마
