# Galaxy Flagship Evolution Simulator Agent

A GitHub-ready agent specification for analyzing Samsung Galaxy S-Series flagship evolution from **Galaxy S23 Series to Galaxy S27 Series**.

The agent compares confirmed S23–S26 specifications and simulates S27 with clearly labeled conservative, base, and aggressive scenarios.

---

## What This Agent Does

- Tracks Galaxy S23 / S23+ / S23 Ultra through Galaxy S26 / S26+ / S26 Ultra.
- Simulates Galaxy S27 / S27+ / S27 Ultra.
- Separates Snapdragon for Galaxy and Exynos AP strategies.
- Treats Ultra as a separate premium flagship track.
- Analyzes AP, CPU, GPU, NPU, ISP, camera, display, battery, charging, and AI.
- Produces GitHub-ready tables, JSON, summaries, scores, and strategic insights.

---

## Files

| File | Purpose |
|---|---|
| `AGENT.md` | Main agent behavior specification |
| `agent_config.json` | Machine-readable agent configuration |
| `agent_config.yaml` | YAML version of the agent configuration |
| `prompts/system_prompt.md` | System prompt for the agent |
| `prompts/user_prompt_template.md` | Reusable user prompt template |
| `prompts/output_template.md` | Standard output template |
| `data/scoring_weights.json` | Flagship score weighting model |

---

## Quick Start

Use the system prompt from:

```text
prompts/system_prompt.md
```

Then provide a user prompt such as:

```text
S23 전 모델부터 S27 전 모델까지 플래그십 진화 시뮬레이션 해줘.
다음 항목을 포함해줘:
1. S23 전 모델 → S26 전 모델 확정 스펙 변화
2. S27 전 모델 보수/기준/공격 시나리오
3. AP 전략 변화
4. 카메라 센서 변화
5. AI 기능 변화
6. 배터리/충전 변화
7. 종합 플래그십 점수
8. 추천 시나리오
```

---

## Data Policy

| Generation | Treatment |
|---|---|
| S23–S26 | Confirmed or reliable public data |
| S27 | Prediction / assumption / scenario only |

S27 outputs must always be labeled as:

```text
Prediction / Assumption / Scenario
```

---

## Recommended Scenario

The default recommendation logic favors the **Base Scenario**, because it balances:

- Technical feasibility
- Cost
- Thermal behavior
- Supply-chain reliability
- Consumer-perceived upgrade value

---

## License

MIT License recommended.
