"""
Excel Extractor Agent
- Reads an Excel file
- Filters, selects, renames, sorts columns by YAML rules
- Exports extracted data and optional summary to a new Excel file
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


@dataclass
class ExtractRule:
    input_file: Path
    input_sheet: str | int
    output_file: Path
    output_sheet: str
    keep_columns: list[str]
    rename_columns: dict[str, str]
    filters: list[dict[str, Any]]
    sort_by: str | None
    sort_ascending: bool
    summary_enabled: bool
    summary_group_by: list[str]
    summary_metrics: dict[str, str]


class ExcelExtractorAgent:
    def __init__(self, rule_path: str | Path):
        self.rule_path = Path(rule_path)
        self.base_dir = self.rule_path.parent.parent
        self.rule = self._load_rule()

    def _resolve(self, path: str | Path) -> Path:
        p = Path(path)
        return p if p.is_absolute() else self.base_dir / p

    def _load_rule(self) -> ExtractRule:
        with self.rule_path.open("r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        return ExtractRule(
            input_file=self._resolve(config["input"]["file"]),
            input_sheet=config["input"].get("sheet", 0),
            output_file=self._resolve(config["output"]["file"]),
            output_sheet=config["output"].get("sheet", "ExtractedData"),
            keep_columns=config.get("columns", {}).get("keep", []),
            rename_columns=config.get("columns", {}).get("rename", {}),
            filters=config.get("filters", []),
            sort_by=config.get("sort", {}).get("by"),
            sort_ascending=config.get("sort", {}).get("ascending", True),
            summary_enabled=config.get("summary", {}).get("enabled", False),
            summary_group_by=config.get("summary", {}).get("group_by", []),
            summary_metrics=config.get("summary", {}).get("metrics", {}),
        )

    def read_excel(self) -> pd.DataFrame:
        if not self.rule.input_file.exists():
            raise FileNotFoundError(f"Input file not found: {self.rule.input_file}")
        return pd.read_excel(self.rule.input_file, sheet_name=self.rule.input_sheet)

    @staticmethod
    def _apply_single_filter(df: pd.DataFrame, condition: dict[str, Any]) -> pd.DataFrame:
        column = condition["column"]
        operator = condition["operator"]
        value = condition.get("value")

        if column not in df.columns:
            raise KeyError(f"Filter column not found: {column}")

        if operator == "eq":
            return df[df[column] == value]
        if operator == "ne":
            return df[df[column] != value]
        if operator == "gt":
            return df[df[column] > value]
        if operator == "gte":
            return df[df[column] >= value]
        if operator == "lt":
            return df[df[column] < value]
        if operator == "lte":
            return df[df[column] <= value]
        if operator == "contains":
            return df[df[column].astype(str).str.contains(str(value), case=False, na=False)]
        if operator == "in":
            return df[df[column].isin(value)]

        raise ValueError(f"Unsupported filter operator: {operator}")

    def transform(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame | None]:
        result = df.copy()

        for condition in self.rule.filters:
            result = self._apply_single_filter(result, condition)

        if self.rule.keep_columns:
            missing = [c for c in self.rule.keep_columns if c not in result.columns]
            if missing:
                raise KeyError(f"Missing keep columns: {missing}")
            result = result[self.rule.keep_columns]

        result = result.rename(columns=self.rule.rename_columns)

        sort_by = self.rule.rename_columns.get(self.rule.sort_by, self.rule.sort_by)
        if sort_by:
            if sort_by not in result.columns:
                raise KeyError(f"Sort column not found: {sort_by}")
            result = result.sort_values(by=sort_by, ascending=self.rule.sort_ascending)

        summary_df = None
        if self.rule.summary_enabled:
            group_by = [self.rule.rename_columns.get(c, c) for c in self.rule.summary_group_by]
            metrics = {self.rule.rename_columns.get(k, k): v for k, v in self.rule.summary_metrics.items()}
            if group_by and metrics:
                summary_df = result.groupby(group_by, dropna=False).agg(metrics).reset_index()

        return result, summary_df

    def export(self, result: pd.DataFrame, summary: pd.DataFrame | None = None) -> None:
        self.rule.output_file.parent.mkdir(parents=True, exist_ok=True)
        with pd.ExcelWriter(self.rule.output_file, engine="openpyxl") as writer:
            result.to_excel(writer, sheet_name=self.rule.output_sheet, index=False)
            if summary is not None:
                summary.to_excel(writer, sheet_name="Summary", index=False)

        self._format_output_file()

    def _format_output_file(self) -> None:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment

        wb = load_workbook(self.rule.output_file)
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill(fill_type="solid", fgColor="1F4E78")
                cell.alignment = Alignment(horizontal="center")

            for column_cells in ws.columns:
                max_len = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = min(max(max_len + 2, 12), 35)

        wb.save(self.rule.output_file)

    def run(self) -> Path:
        df = self.read_excel()
        result, summary = self.transform(df)
        self.export(result, summary)
        return self.rule.output_file


if __name__ == "__main__":
    agent = ExcelExtractorAgent("config/extract_rules.yaml")
    output_path = agent.run()
    print(f"Done: {output_path}")
