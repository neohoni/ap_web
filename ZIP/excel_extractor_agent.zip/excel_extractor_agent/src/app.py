from pathlib import Path
import tempfile

import pandas as pd
import streamlit as st

from excel_extractor_agent import ExcelExtractorAgent

st.set_page_config(page_title="Excel Extractor Agent", layout="wide")
st.title("Excel Extractor Agent")
st.write("엑셀 파일을 업로드하고 YAML 규칙에 따라 데이터를 추출한 뒤 새 엑셀로 저장합니다.")

uploaded_excel = st.file_uploader("Input Excel", type=["xlsx"])
uploaded_rule = st.file_uploader("Rule YAML", type=["yaml", "yml"])

if uploaded_excel and uploaded_rule and st.button("Run Extraction"):
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        project = tmp_path / "agent"
        (project / "samples").mkdir(parents=True)
        (project / "config").mkdir(parents=True)
        (project / "output").mkdir(parents=True)

        excel_path = project / "samples" / "input.xlsx"
        rule_path = project / "config" / "extract_rules.yaml"
        excel_path.write_bytes(uploaded_excel.read())
        rule_text = uploaded_rule.read().decode("utf-8").replace("samples/sample_input.xlsx", "samples/input.xlsx")
        rule_path.write_text(rule_text, encoding="utf-8")

        agent = ExcelExtractorAgent(rule_path)
        output_path = agent.run()

        st.success("추출 완료")
        st.download_button(
            "Download Result Excel",
            data=output_path.read_bytes(),
            file_name="extracted_result.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
