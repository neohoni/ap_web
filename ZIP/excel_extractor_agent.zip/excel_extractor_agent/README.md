# Excel Extractor Agent

엑셀 파일을 읽고 원하는 조건의 데이터를 추출한 뒤, 새 엑셀 파일로 다시 저장하는 로컬 실행형 에이전트입니다.

## 주요 기능

- `.xlsx` 파일 읽기
- 원하는 컬럼만 선택
- 컬럼명 변경
- 조건 필터링
- 정렬
- 요약 시트 자동 생성
- 결과 엑셀 자동 서식 적용
- Streamlit 기반 간단한 UI 제공

## 폴더 구조

```text
excel_extractor_agent/
├── README.md
├── requirements.txt
├── config/
│   └── extract_rules.yaml
├── samples/
│   └── sample_input.xlsx
├── output/
│   └── extracted_result.xlsx
├── src/
│   ├── excel_extractor_agent.py
│   └── app.py
└── tests/
```

## 설치

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## CLI 실행

```bash
python src/excel_extractor_agent.py
```

실행 후 결과 파일이 생성됩니다.

```text
output/extracted_result.xlsx
```

## UI 실행

```bash
streamlit run src/app.py
```

브라우저에서 엑셀 파일과 YAML 규칙 파일을 업로드하면 결과 엑셀을 다운로드할 수 있습니다.

## 추출 규칙 예시

```yaml
input:
  file: samples/sample_input.xlsx
  sheet: Sales

output:
  file: output/extracted_result.xlsx
  sheet: ExtractedData

columns:
  keep:
    - Date
    - Product
    - Region
    - Sales
    - Cost
    - Profit
    - Status
  rename:
    Sales: Revenue
    Cost: Expense

filters:
  - column: Status
    operator: eq
    value: Confirmed
  - column: Profit
    operator: gte
    value: 100000

sort:
  by: Profit
  ascending: false

summary:
  enabled: true
  group_by:
    - Region
  metrics:
    Revenue: sum
    Expense: sum
    Profit: sum
```

## 지원 필터 연산자

| Operator | 의미 |
|---|---|
| `eq` | 같음 |
| `ne` | 같지 않음 |
| `gt` | 초과 |
| `gte` | 이상 |
| `lt` | 미만 |
| `lte` | 이하 |
| `contains` | 문자열 포함 |
| `in` | 목록 포함 |

## GitHub 업로드

```bash
git init
git add .
git commit -m "Add Excel Extractor Agent"
git branch -M main
git remote add origin https://github.com/사용자명/excel_extractor_agent.git
git push -u origin main
```

## 추가 연동 방법

### 1. 사내 리포트 자동화

- 원본 엑셀을 `samples/` 또는 지정 폴더에 저장
- `extract_rules.yaml`의 필터와 컬럼 규칙 수정
- 매일/매주 CLI 실행으로 리포트 자동 생성

### 2. 배치 작업 연동

Linux cron 예시:

```bash
0 9 * * 1 cd /path/excel_extractor_agent && .venv/bin/python src/excel_extractor_agent.py
```

### 3. 다른 시스템과 연동

- 결과 엑셀을 공유 폴더에 저장
- 결과 파일을 메일/Slack/Notion 자동 업로드 파이프라인에 연결
- 추후 DB, API, Google Sheets 입력으로 확장 가능

## 설계 포인트

이 구조는 칩 설계 / 임베디드 알고리즘 / 시스템 설계 관점에서 데이터 추출 파이프라인을 명확히 분리합니다.

- 입력 계층: Excel Reader
- 규칙 계층: YAML Rule Engine
- 처리 계층: Filter / Select / Rename / Sort / Summary
- 출력 계층: Excel Writer
- UI 계층: Streamlit App
